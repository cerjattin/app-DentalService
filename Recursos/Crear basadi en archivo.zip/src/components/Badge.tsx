type BadgeVariant =
  | 'programada' | 'checkin' | 'espera' | 'atencion' | 'terminada'
  | 'pendiente-firma' | 'firmada' | 'cerrada' | 'declarada'
  | 'cancelada' | 'no-asistio' | 'correccion' | 'anulada'
  | 'borrador' | 'preparacion' | 'validando' | 'listo' | 'exportado'
  | 'activo' | 'inactivo' | 'admin' | 'recepcion' | 'profesional'
  | 'success' | 'warning' | 'danger' | 'info' | 'neutral'

const variantMap: Record<BadgeVariant, { label: string; className: string }> = {
  programada:       { label: 'Programada',          className: 'bg-slate-100 text-slate-700' },
  checkin:          { label: 'Check-in',             className: 'bg-blue-100 text-blue-700' },
  espera:           { label: 'En espera',            className: 'bg-amber-100 text-amber-700' },
  atencion:         { label: 'En atención',          className: 'bg-indigo-100 text-indigo-700' },
  terminada:        { label: 'Atención terminada',   className: 'bg-teal-100 text-teal-700' },
  'pendiente-firma':{ label: 'Pendiente firma',      className: 'bg-orange-100 text-orange-700' },
  firmada:          { label: 'Firmada',              className: 'bg-emerald-100 text-emerald-700' },
  cerrada:          { label: 'Cerrada',              className: 'bg-green-100 text-green-700' },
  declarada:        { label: 'Declarada SVB',        className: 'bg-purple-100 text-purple-700' },
  cancelada:        { label: 'Cancelada',            className: 'bg-red-100 text-red-600' },
  'no-asistio':     { label: 'No asistió',           className: 'bg-gray-100 text-gray-600' },
  correccion:       { label: 'Requiere corrección',  className: 'bg-yellow-100 text-yellow-700' },
  anulada:          { label: 'Anulada',              className: 'bg-red-200 text-red-700' },
  borrador:         { label: 'Borrador',             className: 'bg-slate-100 text-slate-600' },
  preparacion:      { label: 'Preparación',          className: 'bg-blue-100 text-blue-700' },
  validando:        { label: 'Validando',            className: 'bg-amber-100 text-amber-700' },
  listo:            { label: 'Listo',                className: 'bg-green-100 text-green-700' },
  exportado:        { label: 'Exportado',            className: 'bg-purple-100 text-purple-700' },
  activo:           { label: 'Activo',               className: 'bg-green-100 text-green-700' },
  inactivo:         { label: 'Inactivo',             className: 'bg-red-100 text-red-600' },
  admin:            { label: 'Administrador',        className: 'bg-indigo-100 text-indigo-700' },
  recepcion:        { label: 'Recepción',            className: 'bg-sky-100 text-sky-700' },
  profesional:      { label: 'Profesional',          className: 'bg-teal-100 text-teal-700' },
  success:          { label: '',                     className: 'bg-green-100 text-green-700' },
  warning:          { label: '',                     className: 'bg-amber-100 text-amber-700' },
  danger:           { label: '',                     className: 'bg-red-100 text-red-600' },
  info:             { label: '',                     className: 'bg-blue-100 text-blue-700' },
  neutral:          { label: '',                     className: 'bg-slate-100 text-slate-600' },
}

interface BadgeProps {
  variant: BadgeVariant
  label?: string
  dot?: boolean
  size?: 'sm' | 'md'
}

export default function Badge({ variant, label, dot, size = 'md' }: BadgeProps) {
  const cfg = variantMap[variant]
  const text = label ?? cfg.label
  const sizeClass = size === 'sm' ? 'text-[11px] px-1.5 py-0.5' : 'text-xs px-2 py-1'
  return (
    <span className={`inline-flex items-center gap-1 font-medium rounded-full ${sizeClass} ${cfg.className}`}>
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />}
      {text}
    </span>
  )
}
