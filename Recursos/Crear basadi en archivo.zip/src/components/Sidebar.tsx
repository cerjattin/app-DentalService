import type { Page, Role } from '../types'

const adminNav: { label: string; page: Page; icon: string }[] = [
  { label: 'Dashboard', page: 'admin-dashboard', icon: '⬛' },
  { label: 'Agenda', page: 'agenda', icon: '📅' },
  { label: 'Pacientes', page: 'patients', icon: '👤' },
  { label: 'Facturas', page: 'invoices', icon: '🧾' },
  { label: 'Producción', page: 'production', icon: '📊' },
  { label: 'Declaraciones SVB', page: 'declarations', icon: '📋' },
  { label: 'Procedimientos SVB', page: 'procedures', icon: '🦷' },
  { label: 'Profesionales', page: 'professionals', icon: '👨‍⚕️' },
  { label: 'Usuarios', page: 'users', icon: '🔐' },
  { label: 'Auditoría', page: 'audit', icon: '📝' },
  { label: 'Configuración', page: 'config', icon: '⚙️' },
]

const receptionNav: { label: string; page: Page; icon: string }[] = [
  { label: 'Inicio', page: 'reception-dashboard', icon: '🏠' },
  { label: 'Agenda', page: 'agenda', icon: '📅' },
  { label: 'Pacientes', page: 'patients', icon: '👤' },
  { label: 'Facturas', page: 'invoices', icon: '🧾' },
  { label: 'Pendientes de firma', page: 'signature', icon: '✍️' },
]

const professionalNav: { label: string; page: Page; icon: string }[] = [
  { label: 'Mi agenda', page: 'professional-dashboard', icon: '📅' },
  { label: 'Pacientes esperando', page: 'reception-dashboard', icon: '⏳' },
  { label: 'Atenciones', page: 'clinical', icon: '🦷' },
  { label: 'Historial', page: 'invoices', icon: '📂' },
]

function NavItem({
  item,
  active,
  onClick,
}: {
  item: { label: string; page: Page; icon: string }
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 text-left
        ${active
          ? 'bg-white/15 text-white'
          : 'text-white/60 hover:bg-white/10 hover:text-white/90'
        }`}
    >
      <span className="text-base leading-none opacity-80">{item.icon}</span>
      <span>{item.label}</span>
      {active && <span className="ml-auto w-1 h-1 rounded-full bg-blue-300" />}
    </button>
  )
}

interface SidebarProps {
  role: Role
  currentPage: Page
  onNavigate: (page: Page) => void
  onRoleChange: (role: Role) => void
}

export default function Sidebar({ role, currentPage, onNavigate, onRoleChange }: SidebarProps) {
  const nav = role === 'admin' ? adminNav : role === 'reception' ? receptionNav : professionalNav

  const roleLabel = role === 'admin' ? 'Administrador' : role === 'reception' ? 'Recepción' : 'Profesional'

  return (
    <aside
      className="flex flex-col h-full"
      style={{ backgroundColor: '#0B1F3A', width: '220px', minWidth: '220px' }}
    >
      {/* Brand */}
      <div className="px-4 py-5 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm"
            style={{ backgroundColor: '#1A6FE8' }}
          >
            OS
          </div>
          <div>
            <div className="text-white font-semibold text-sm leading-tight">OdonthoServices</div>
            <div className="text-white/40 text-[10px] font-mono tracking-wide uppercase">SVB Billing</div>
          </div>
        </div>
      </div>

      {/* Role switcher (demo) */}
      <div className="px-3 py-3 border-b border-white/10">
        <div className="text-white/30 text-[10px] font-mono uppercase tracking-wider mb-1.5 px-1">Vista demo</div>
        <div className="flex flex-col gap-0.5">
          {(['admin', 'reception', 'professional'] as Role[]).map((r) => (
            <button
              key={r}
              onClick={() => onRoleChange(r)}
              className={`text-left text-xs px-2 py-1 rounded transition-all ${
                role === r ? 'bg-blue-600/40 text-blue-200' : 'text-white/40 hover:text-white/70'
              }`}
            >
              {r === 'admin' ? 'Administrador' : r === 'reception' ? 'Recepción' : 'Profesional'}
            </button>
          ))}
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-0.5">
        {nav.map((item) => (
          <NavItem
            key={item.page}
            item={item}
            active={currentPage === item.page}
            onClick={() => onNavigate(item.page)}
          />
        ))}
      </nav>

      {/* User footer */}
      <div className="px-3 py-3 border-t border-white/10">
        <div className="flex items-center gap-2.5 px-1">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold text-white"
            style={{ backgroundColor: '#1A6FE8' }}
          >
            {role === 'admin' ? 'AD' : role === 'reception' ? 'RC' : 'DR'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white/80 text-xs font-medium truncate">
              {role === 'admin' ? 'Admin General' : role === 'reception' ? 'Recepción' : 'Dr. Pérez'}
            </div>
            <div className="text-white/30 text-[10px] truncate">{roleLabel}</div>
          </div>
          <button className="text-white/30 hover:text-white/60 text-sm transition-colors" title="Cerrar sesión">
            ↩
          </button>
        </div>
      </div>
    </aside>
  )
}
