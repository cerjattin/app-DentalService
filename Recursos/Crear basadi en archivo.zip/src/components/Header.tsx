import { useState } from 'react'

const notifications = [
  { id: 1, text: 'Factura #SVB-00234 está pendiente de firma.', time: '10:42 AM', unread: true },
  { id: 2, text: 'Paciente de las 10:30 llegó a recepción.', time: '10:31 AM', unread: true },
  { id: 3, text: '3 registros tienen errores antes de generar la declaración.', time: '9:15 AM', unread: false },
]

interface HeaderProps {
  title: string
  subtitle?: string
  onSearch?: (q: string) => void
}

export default function Header({ title, subtitle, onSearch }: HeaderProps) {
  const [showNotifications, setShowNotifications] = useState(false)
  const [searchQ, setSearchQ] = useState('')
  const unread = notifications.filter((n) => n.unread).length

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center gap-4">
      {/* Title */}
      <div className="flex-1 min-w-0">
        <h1 className="text-base font-semibold text-slate-800 leading-tight">{title}</h1>
        {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
      </div>

      {/* Global search */}
      <div className="relative hidden md:block">
        <input
          type="text"
          value={searchQ}
          onChange={(e) => {
            setSearchQ(e.target.value)
            onSearch?.(e.target.value)
          }}
          placeholder="Buscar paciente, factura, SVB Card o cita..."
          className="w-72 pl-8 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg bg-slate-50 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
        />
        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
      </div>

      {/* Notifications */}
      <div className="relative">
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <span className="text-base">🔔</span>
          {unread > 0 && (
            <span
              className="absolute top-1 right-1 w-4 h-4 text-[10px] font-bold text-white rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#DC2626' }}
            >
              {unread}
            </span>
          )}
        </button>
        {showNotifications && (
          <div className="absolute right-0 top-full mt-2 w-80 bg-white border border-slate-200 rounded-xl shadow-xl z-50">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-700">Notificaciones</span>
              <span className="text-xs text-blue-600 cursor-pointer hover:underline">Marcar como leídas</span>
            </div>
            <div className="divide-y divide-slate-100">
              {notifications.map((n) => (
                <div key={n.id} className={`px-4 py-3 ${n.unread ? 'bg-blue-50/40' : ''}`}>
                  <p className="text-xs text-slate-700 leading-relaxed">{n.text}</p>
                  <p className="text-[10px] text-slate-400 mt-1">{n.time}</p>
                </div>
              ))}
            </div>
            <div className="px-4 py-2 border-t border-slate-100 text-center">
              <span className="text-xs text-slate-500 cursor-pointer hover:text-blue-600">Ver todas</span>
            </div>
          </div>
        )}
      </div>

      {/* Time */}
      <div className="text-xs font-mono text-slate-400 hidden lg:block">
        {new Date().toLocaleTimeString('es-CW', { hour: '2-digit', minute: '2-digit' })}
      </div>
    </header>
  )
}
