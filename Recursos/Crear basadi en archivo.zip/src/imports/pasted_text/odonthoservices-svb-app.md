# Prompt para Figma Make — OdonthoServices SVB Billing App

Diseña la experiencia UI/UX completa de una **aplicación web interna para una clínica dental llamada OdonthoServices**, ubicada en Curaçao.

La aplicación funcionará principalmente dentro de la **red local de la clínica** y será utilizada por recepción, odontólogos/profesionales, asistentes y administración.

No diseñes una página web pública ni una landing page. Diseña un **software empresarial / healthcare management web app**, moderno, profesional, rápido de operar y optimizado para uso diario en recepción y consultorios.

---

# 1. OBJETIVO PRINCIPAL DEL SOFTWARE

La aplicación debe controlar el flujo completo de atención de pacientes asegurados por **SVB — Sociale Verzekeringsbank Curaçao**, desde que el paciente llega a recepción hasta que se genera, firma y cierra su factura/declaración.

Flujo general:

**Paciente llega → Recepción → Identificación del paciente → Selección/creación de cita → Check-in → Profesional atiende → Registra diagnóstico y procedimientos → Calcula factura SVB → Revisión → Firma digital del paciente → Cierre → PDF oficial → Declaración SVB**

El sistema debe permitir además generar posteriormente archivos de declaración SVB en formato CSV/TXT.

---

# 2. PRINCIPIOS DE DISEÑO

Crear una interfaz:

* Profesional y clínica.
* Moderna.
* Muy clara visualmente.
* Desktop-first.
* Responsive para tablets.
* Optimizada para pantallas 1366×768, 1440×900 y 1920×1080.
* Navegación rápida.
* Formularios simples.
* Pocos clics para tareas frecuentes.
* Botones de acciones principales claramente diferenciados.
* Excelente legibilidad.
* Uso mínimo de modales.
* Estados claramente identificables mediante badges.
* Tablas con filtros, búsqueda y acciones rápidas.
* Interfaz adecuada para personal que utilizará el sistema durante toda la jornada.

Evitar diseños tipo landing page, ecommerce o dashboard excesivamente decorativo.

Priorizar funcionalidad clínica y velocidad.

---

# 3. ESTILO VISUAL

Crear una apariencia premium de software médico/odontológico.

Paleta sugerida:

* Azul oscuro / navy como color institucional principal.
* Azul clínico para acciones.
* Blanco como fondo predominante.
* Gris muy claro para fondos secundarios.
* Verde para procesos completados.
* Amarillo/ámbar para pendientes.
* Rojo únicamente para errores, anulaciones o situaciones críticas.

Características:

* Sidebar lateral.
* Header superior.
* Cards limpias.
* Bordes ligeramente redondeados.
* Sombras muy suaves.
* Iconografía médica y administrativa moderna.
* Tipografía profesional sans-serif.
* Buen contraste.
* Mucho espacio visual.
* Formularios organizados por secciones.

---

# 4. ROLES DEL SISTEMA

Diseña experiencias diferentes según el usuario.

## ADMINISTRADOR

Acceso completo.

Puede:

* Administrar usuarios.
* Crear usuarios.
* Editar usuarios.
* Activar/desactivar usuarios.
* Asignar roles.
* Administrar profesionales.
* Configurar Provider ID SVB de cada profesional.
* Administrar pacientes.
* Administrar citas.
* Corregir citas cuando existen errores.
* Consultar todas las facturas.
* Consultar facturas pendientes.
* Consultar facturas cerradas.
* Consultar facturas anuladas/corregidas.
* Administrar maestro de procedimientos SVB.
* Administrar precios/tarifas.
* Administrar códigos de diagnóstico.
* Administrar datos de configuración SVB.
* Generar archivos de declaración.
* Generar PDFs.
* Consultar auditoría.
* Consultar producción.
* Consultar estadísticas en tiempo real.

---

## RECEPCIÓN

Puede:

* Buscar pacientes.
* Registrar nuevos pacientes.
* Actualizar información administrativa del paciente.
* Crear citas.
* Consultar agenda.
* Realizar check-in.
* Ver pacientes esperando.
* Identificar profesional asignado.
* Ver estado de cada cita.
* Revisar factura preparada por el profesional.
* Solicitar firma al paciente.
* Capturar firma digital.
* Cerrar factura.
* Descargar/imprimir PDF.

No debe poder modificar tarifas o configuración SVB.

---

## PROFESIONAL / ODONTÓLOGO

Puede:

* Ver agenda personal.
* Ver pacientes esperando.
* Abrir cita.
* Consultar información del paciente.
* Registrar diagnóstico.
* Seleccionar procedimientos realizados.
* Indicar cantidad.
* Indicar autorización SVB cuando corresponda.
* Indicar si hubo asistencia.
* Indicar clínica/policlínica.
* Agregar observaciones.
* Visualizar subtotal y total.
* Finalizar atención.
* Enviar factura a recepción para firma.

Debe existir una experiencia especialmente rápida para agregar procedimientos.

---

# 5. ESTADOS DEL WORKFLOW

Representar visualmente los estados de la cita:

1. Programada
2. Paciente registrado
3. Check-in realizado
4. En espera
5. En atención
6. Atención terminada
7. Factura pendiente de revisión
8. Pendiente de firma
9. Firmada
10. Factura cerrada
11. Declarada a SVB

Estados administrativos adicionales:

* Cancelada
* No asistió
* Requiere corrección
* Anulada

Usar badges visuales consistentes.

---

# 6. LOGIN

Crear pantalla:

## Login OdonthoServices

Elementos:

* Logo OdonthoServices.
* Usuario o correo.
* Contraseña.
* Mostrar/ocultar contraseña.
* Botón "Iniciar sesión".
* Mensajes de error.
* Estado de conexión al servidor local.

Diseño limpio y profesional.

---

# 7. DASHBOARD ADMINISTRADOR

Crear un dashboard ejecutivo pero operativo.

Encabezado:

**Dashboard**

Filtros:

* Hoy
* Ayer
* Esta semana
* Este mes
* Rango personalizado
* Profesional

KPIs principales:

### Producción de hoy

ANG XX,XXX

### Facturado SVB

ANG XX,XXX

### Pacientes atendidos

XX

### Citas de hoy

XX

### Facturas pendientes de firma

XX

### Facturas cerradas

XX

### Facturas pendientes de declarar

XX

Crear gráfica:

## Producción por profesional

Mostrar:

* Profesional
* Pacientes
* Procedimientos
* Valor facturado
* % de producción

Actualizar en tiempo real.

Ejemplo:

| Profesional | Pacientes | Procedimientos | Producción |
| Dr. A | 12 | 21 | ANG 4,350 |
| Dr. B | 9 | 17 | ANG 3,100 |

Crear gráfica:

**Producción acumulada del día**

Eje horizontal:
Horas del día.

Eje vertical:
Valor facturado.

---

# 8. DASHBOARD RECEPCIÓN

La página principal de recepción debe funcionar como un centro de operaciones.

Mostrar:

### Pacientes de hoy

Tabla:

* Hora
* Paciente
* SVB Card
* Profesional
* Motivo
* Estado
* Factura
* Acción

Ejemplo de estados:

* Esperando
* En atención
* Pendiente firma
* Cerrada

Acciones rápidas:

* Registrar llegada
* Abrir paciente
* Abrir cita
* Firmar factura
* Cerrar factura

Agregar arriba:

**Buscar paciente**

Permitir buscar por:

* Nombre
* Documento
* SVB Seguro Card
* Número de paciente
* Teléfono

---

# 9. REGISTRO DE PACIENTE

Diseñar una pantalla:

**Nuevo paciente**

Dividir formulario en secciones.

## Información personal

* Nombre
* Apellidos
* Fecha nacimiento
* Sexo
* Documento
* Teléfono
* Email
* Dirección

## Información SVB

* SVB Seguro Card Number / SVB VerzekerdeId
* Estado de afiliación
* Fecha vencimiento si aplica

## Información adicional

* Médico remitente
* Código del médico remitente
* Observaciones

Botones:

Cancelar

Guardar paciente

Guardar y crear cita

---

# 10. AGENDA / CITAS

Crear una agenda clínica.

Modos:

* Día
* Semana
* Lista

Filtrar por:

* Profesional
* Consultorio
* Estado

Cada cita debe mostrar:

* Hora
* Paciente
* Profesional
* Duración
* Estado

Utilizar colores suaves por estado.

Al seleccionar una cita abrir panel lateral o página de detalle.

---

# 11. DETALLE DE CITA

Encabezado:

**Cita #APT-000234**

Mostrar:

Paciente

SVB Card

Fecha

Hora

Profesional

Estado

Crear timeline:

Programada → Check-in → Atención → Facturación → Firma → Cerrada

Acciones según rol.

---

# 12. PANTALLA DEL PROFESIONAL

Esta debe ser una de las pantallas más importantes de la aplicación.

Encabezado:

**Atención del paciente**

Mostrar arriba una tarjeta compacta:

Nombre del paciente

SVB Card

Fecha nacimiento

Cita

Profesional

Estado

Luego pestañas:

### Atención

### Facturación

### Historial

---

# 13. REGISTRO DE DIAGNÓSTICO

Sección:

**Diagnóstico**

Campo:

Código diagnóstico ICD-10

Debe tener buscador/autocomplete.

Ejemplo:

Buscar por:

* Código
* Descripción

Mostrar:

Código

Descripción

Permitir seleccionar uno o varios según futura configuración del sistema.

---

# 14. SELECCIÓN DE PROCEDIMIENTOS SVB

Diseñar un componente rápido y muy usable.

Título:

**Procedimientos realizados**

Botón:

* Agregar procedimiento

Al presionarlo abrir buscador.

Permitir buscar:

* Código SVB
* Nombre
* Descripción

Resultados tipo tabla:

| Código | Procedimiento | Tarifa | Agregar |

Después de agregar procedimiento mostrar tabla:

| Código | Descripción | Cantidad | Tarifa | Total | Opciones |

Cada línea debe permitir editar:

### Treatment ID / Verrichtingscode

Código SVB del procedimiento.

### Description

Nombre del procedimiento.

### Amount

Tarifa.

### Number of treatments

Cantidad realizada.

### Authorization ID

Número de autorización cuando sea necesario.

### Assistance

Selector:

Y — Yes

N — No

### Poli/Clinic

Selector:

P — Policlinic

K — Clinic

### Additional note

Campo máximo 100 caracteres.

Permitir eliminar procedimiento antes de cerrar la factura.

---

# 15. RESUMEN DE LA ATENCIÓN

En la parte derecha de la pantalla crear panel sticky:

**Resumen**

Paciente

Procedimientos: 3

Subtotal:
ANG XXX

Total:
ANG XXX

Estado:
En atención

Botón principal:

**Finalizar atención**

Antes de terminar validar campos obligatorios.

---

# 16. FACTURA SVB

Cuando el profesional finaliza la atención generar una factura preliminar.

Diseñar pantalla:

# Factura SVB

Mostrar una representación digital muy cercana al formato oficial SVB.

Encabezado:

SVB Notaformulier

Datos:

### Naam SVB-verzekerde

Nombre del asegurado

### SVB Seguro Cardnr

Número SVB

### Detail factuurnummer

Número de factura por paciente

### OMF-nummer

Número OMF en caso de accidente

### Diagnosecode

Código diagnóstico

### Code & naam verwijzend arts

Código y nombre del médico remitente

---

# 17. TABLA DE PROCEDIMIENTOS DE LA FACTURA

Mostrar columnas:

* Datum
* Verrichtingscode
* Omschrijving
* Macht-nummer
* Aantal
* Assistentie J/N
* (Poli) Klinisch P/K
* Bedrag
* Opmerkingen

Mostrar al final:

**Totaal bedrag**

Luego:

**Code en naam medewerkende**

Código y nombre del profesional que realizó el tratamiento.

---

# 18. FIRMA DIGITAL DEL PACIENTE

Crear un paso específico:

# Firma del paciente

Mostrar resumen de factura:

Paciente

Fecha

Profesional

Procedimientos

Total

Texto:

"He revisado los procedimientos registrados correspondientes a mi atención."

Crear un área grande:

**Firmar aquí**

Debe ser compatible conceptualmente con:

* Tableta digitalizadora de firma.
* Pantalla táctil.
* Mouse.

Controles:

Limpiar firma

Reintentar

Confirmar firma

Mostrar después una vista previa de la firma.

Botón:

**Firmar y cerrar factura**

Mostrar confirmación:

"Una vez cerrada la factura no podrá modificarse de manera normal."

Cancelar

Confirmar cierre

---

# 19. FACTURA CERRADA

Después de la firma mostrar:

✓ Factura cerrada

Información:

Número factura

Paciente

Fecha

Profesional

Total

Firma registrada

Fecha/hora de firma

Acciones:

**Ver PDF**

**Descargar PDF**

**Imprimir**

La factura cerrada no debe permitir edición directa.

---

# 20. CORRECCIONES ADMINISTRATIVAS

Crear un mecanismo controlado para errores.

Administrador puede acceder a:

**Solicitar corrección**

Debe escribir:

Motivo de la corrección

Mostrar:

Usuario

Fecha

Factura afectada

Datos anteriores

Datos nuevos

Toda corrección debe quedar en auditoría.

Nunca reemplazar silenciosamente información histórica.

---

# 21. PDF SVB

Diseñar una vista previa A4 del PDF.

Debe respetar visualmente el documento:

**SVB Notaformulier**

Mostrar:

Naam SVB-verzekerde

SVB Seguro Cardnr

Detail factuurnummer

OMF-nummer

Diagnosecode

Code & naam verwijzend arts

Tabla:

Datum

Verrichtingscode

Omschrijving

Macht-nummer

Aantal

Assistentie J/N

(Poli) Klinisch P/K

Bedrag

Opmerkingen

Final:

Totaal bedrag

Code en naam medewerkende

Paraaf / firma

La firma digital capturada debe aparecer integrada en el PDF.

---

# 22. MAESTRO DE PROCEDIMIENTOS SVB

Crear módulo administrativo:

**Procedimientos SVB**

Tabla:

* Código
* Procedimiento
* Descripción
* Tarifa
* Requiere autorización
* Estado
* Última actualización
* Acciones

Funciones:

Buscar

Filtrar

Crear

Editar

Activar

Desactivar

Importar catálogo

Exportar catálogo

---

# 23. PROFESIONALES

Módulo:

**Profesionales**

Tabla:

* Nombre
* Especialidad
* Provider ID
* Estado
* Producción hoy
* Producción mes
* Acciones

Ficha:

Nombre

Especialidad

SVB Provider ID

Usuario asociado

Estado

---

# 24. USUARIOS

Módulo administrativo:

**Usuarios**

Tabla:

* Nombre
* Usuario
* Rol
* Profesional asociado
* Estado
* Último acceso
* Acciones

Roles:

Administrador

Recepción

Profesional

Permitir:

Crear usuario

Editar

Restablecer contraseña

Activar

Desactivar

Asignar rol

---

# 25. PRODUCCIÓN

Crear módulo:

# Producción

Filtros:

Fecha

Rango de fechas

Profesional

Procedimiento

Estado factura

Mostrar KPIs:

Total facturado

Pacientes

Facturas

Procedimientos

Promedio por paciente

Crear gráfica:

**Producción por profesional**

Crear gráfica:

**Producción diaria**

Crear gráfica:

**Procedimientos más realizados**

Crear tabla:

| Profesional | Pacientes | Procedimientos | Facturado |

Al hacer clic en un profesional mostrar detalle.

---

# 26. PRODUCCIÓN EN TIEMPO REAL

Crear widget administrativo:

**Producción de hoy — Live**

Ejemplo:

Dr. Juan Pérez
ANG 4,250
11 pacientes
19 procedimientos

Dra. María Gómez
ANG 3,620
9 pacientes
16 procedimientos

Actualizar visualmente sin recargar la pantalla.

Mostrar:

Última actualización: 10:42 AM

---

# 27. FACTURAS

Módulo:

**Facturas SVB**

Filtros:

* Fecha
* Profesional
* Paciente
* Estado
* Número factura

Estados:

Borrador

Pendiente firma

Firmada

Cerrada

Declarada

Corrección

Anulada

Tabla:

Factura

Paciente

SVB Card

Fecha

Profesional

Total

Estado

Acciones

---

# 28. DECLARACIONES SVB

Crear módulo administrativo:

# Declaraciones SVB

Objetivo:

Agrupar facturas cerradas y preparar la declaración electrónica.

Información del lote:

Declarant ID

Invoice Number

Periodo

Cantidad pacientes

Cantidad procedimientos

Total declarado

Estado

Estados:

Preparación

Validando

Listo

Exportado

Crear botón:

**Generar declaración SVB**

---

# 29. ESTRUCTURA DE EXPORTACIÓN SVB

La aplicación debe contemplar estos campos:

1. Declarant Id
2. Invoicenumber
3. Detail Invoicenumber
4. Provider Id
5. Date
6. Injured Id / SVB insured ID
7. Accident form number / OMF
8. Treatment Id
9. Amount
10. Authorization Id
11. Number of treatments
12. Assistance
13. Id referrer
14. Diagnostic code
15. Poli-clinic
16. Additional note

Crear una pantalla previa a exportar donde el administrador pueda ver la validación de todos los registros.

Mostrar errores como:

"Provider ID debe tener exactamente 5 dígitos."

"SVB ID debe contener exactamente 9 dígitos."

"Treatment ID supera longitud permitida."

"Campo obligatorio vacío."

---

# 30. EXPORTACIÓN

Botones:

**Validar declaración**

**Generar CSV**

**Generar TXT**

**Descargar archivo**

Mostrar estado:

✓ 148 registros válidos

⚠ 3 registros requieren corrección

No permitir exportación definitiva si existen errores críticos.

---

# 31. AUDITORÍA

Crear módulo:

**Audit Log**

Registrar:

* Usuario
* Fecha
* Hora
* Acción
* Paciente
* Cita
* Factura
* Datos modificados
* Motivo

Ejemplos:

Paciente creado

Cita modificada

Procedimiento agregado

Factura firmada

Factura cerrada

Factura corregida

Factura exportada

Usuario modificado

---

# 32. BÚSQUEDA GLOBAL

Crear buscador superior.

Placeholder:

**Buscar paciente, factura, SVB Card o cita...**

Resultados agrupados:

Pacientes

Citas

Facturas

---

# 33. NOTIFICACIONES

Header superior con campana.

Ejemplos:

"Factura #SVB-00234 está pendiente de firma."

"Paciente de las 10:30 llegó a recepción."

"3 registros tienen errores antes de generar la declaración."

---

# 34. SIDEBAR ADMINISTRADOR

Dashboard

Agenda

Pacientes

Facturas

Producción

Declaraciones SVB

Procedimientos SVB

Profesionales

Usuarios

Auditoría

Configuración

---

# 35. SIDEBAR RECEPCIÓN

Inicio

Agenda

Pacientes

Facturas

Pendientes de firma

---

# 36. SIDEBAR PROFESIONAL

Mi agenda

Pacientes esperando

Atenciones

Historial

---

# 37. CONFIGURACIÓN SVB

Crear pantalla administrativa.

Campos:

Declarant ID

Datos de la clínica

Prefijo factura

Secuencia factura

Formato Detail Invoice Number

Configuración PDF

Provider IDs

Directorio de médicos remitentes

Configuración de exportación SVB

---

# 38. ESTADOS VACÍOS

Diseñar estados vacíos profesionales.

Ejemplo:

"No hay pacientes esperando."

"Todas las facturas están firmadas."

"No existen errores en la declaración."

"El profesional no tiene más citas programadas hoy."

---

# 39. MENSAJES Y VALIDACIONES

Crear feedback inmediato.

Ejemplos:

✓ Paciente registrado correctamente.

✓ Atención finalizada.

✓ Firma registrada.

✓ Factura cerrada.

✓ PDF generado.

⚠ Falta código de diagnóstico.

⚠ Este procedimiento requiere autorización SVB.

✕ El número de Seguro Card no tiene el formato requerido.

---

# 40. COMPONENTES REUTILIZABLES

Crear Design System en Figma con:

Buttons

Inputs

Search boxes

Select

Autocomplete

Date picker

Time picker

Tabs

Badges

Cards

Tables

Data grids

Dropdown actions

Confirmation dialogs

Alerts

Toast notifications

Patient card

Appointment card

Professional card

Invoice card

Procedure selector

Signature pad

Timeline

KPI card

Charts

Sidebar

Header

Breadcrumbs

Pagination

---

# 41. PROTOTIPO INTERACTIVO PRINCIPAL

Crear Prototype Flow completo:

### Flujo Recepción

Login

↓

Dashboard recepción

↓

Buscar paciente

↓

Registrar/seleccionar paciente

↓

Crear/seleccionar cita

↓

Check-in

↓

Paciente en espera

---

### Flujo Profesional

Login

↓

Mi agenda

↓

Paciente esperando

↓

Abrir atención

↓

Seleccionar diagnóstico

↓

Agregar procedimientos SVB

↓

Revisar total

↓

Finalizar atención

↓

Enviar a firma

---

### Flujo Recepción / Firma

Pendientes de firma

↓

Abrir factura

↓

Revisar factura

↓

Capturar firma

↓

Confirmar

↓

Cerrar factura

↓

Generar PDF

---

### Flujo Administrador

Dashboard

↓

Producción en tiempo real

↓

Facturas

↓

Declaraciones SVB

↓

Validar registros

↓

Generar CSV/TXT

---

# 42. PANTALLAS QUE FIGMA DEBE GENERAR

Crear como mínimo diseños high-fidelity para:

1. Login
2. Dashboard administrador
3. Dashboard recepción
4. Dashboard profesional
5. Agenda diaria
6. Lista de pacientes
7. Nuevo paciente
8. Perfil paciente
9. Detalle cita
10. Atención clínica
11. Selector procedimientos SVB
12. Factura preliminar
13. Firma digital
14. Factura cerrada
15. Vista PDF
16. Facturas
17. Producción
18. Producción por profesional
19. Procedimientos SVB
20. Usuarios
21. Profesionales
22. Declaraciones SVB
23. Validación declaración
24. Auditoría
25. Configuración

Crear además variantes responsive de las pantallas operativas principales para tablet.

---

# 43. REGLA UX FUNDAMENTAL

El personal clínico debe poder realizar las tareas principales sin navegar innecesariamente.

Objetivos:

Recepción debe poder registrar la llegada de un paciente en pocos clics.

El profesional debe poder agregar procedimientos rápidamente.

Recepción debe poder identificar inmediatamente las facturas pendientes de firma.

Administración debe poder conocer en tiempo real cuánto ha producido cada profesional.

El proceso completo debe tener trazabilidad visual.

---

# 44. IMPORTANTE PARA FIGMA

No crear únicamente wireframes.

Generar:

* Wireframes.
* High-fidelity UI.
* Component library.
* Design system.
* Auto Layout.
* Components.
* Variants.
* Desktop layouts.
* Tablet responsive layouts.
* Prototype interactions.
* Hover states.
* Focus states.
* Disabled states.
* Loading states.
* Error states.
* Empty states.
* Confirmation flows.

Preparar el diseño para que posteriormente pueda convertirse en una aplicación real desarrollada con React/Next.js.

Usar nombres claros de frames, componentes y layers para facilitar el handoff hacia desarrollo.
