import { useState } from 'react'
import type { Page, Role } from './types'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import LoginPage from './pages/LoginPage'
import AdminDashboard from './pages/AdminDashboard'
import ReceptionDashboard from './pages/ReceptionDashboard'
import ProfessionalDashboard from './pages/ProfessionalDashboard'
import PatientsPage from './pages/PatientsPage'
import NewPatientPage from './pages/NewPatientPage'
import ClinicalPage from './pages/ClinicalPage'
import InvoiceDetailPage from './pages/InvoiceDetailPage'
import InvoicesPage from './pages/InvoicesPage'
import SignaturePage from './pages/SignaturePage'
import ClosedInvoicePage from './pages/ClosedInvoicePage'
import AgendaPage from './pages/AgendaPage'
import AppointmentDetailPage from './pages/AppointmentDetailPage'
import SVBDeclarationsPage from './pages/SVBDeclarationsPage'
import ProductionPage from './pages/ProductionPage'
import ProceduresPage from './pages/ProceduresPage'
import UsersPage from './pages/UsersPage'
import AuditPage from './pages/AuditPage'
import ConfigPage from './pages/ConfigPage'

const pageTitles: Record<Page, { title: string; subtitle?: string }> = {
  login:                    { title: 'Iniciar sesión' },
  'admin-dashboard':        { title: 'Dashboard', subtitle: 'Resumen ejecutivo — OdonthoServices' },
  'reception-dashboard':    { title: 'Inicio — Recepción', subtitle: 'Pacientes de hoy y acciones rápidas' },
  'professional-dashboard': { title: 'Mi agenda', subtitle: 'Pacientes y citas del día' },
  agenda:                   { title: 'Agenda', subtitle: 'Programación de citas' },
  patients:                 { title: 'Pacientes', subtitle: 'Gestión de pacientes registrados' },
  'new-patient':            { title: 'Nuevo paciente', subtitle: 'Registro de paciente' },
  'patient-detail':         { title: 'Perfil del paciente', subtitle: 'Información y historial' },
  'appointment-detail':     { title: 'Detalle de cita', subtitle: 'APT-000458' },
  clinical:                 { title: 'Atención clínica', subtitle: 'Registro de procedimientos y facturación' },
  invoices:                 { title: 'Facturas SVB', subtitle: 'Gestión de facturas y estados' },
  'invoice-detail':         { title: 'Vista previa — Factura SVB', subtitle: 'SVB-00233 · Marisela Hato' },
  signature:                { title: 'Firma del paciente', subtitle: 'Captura de firma digital' },
  'closed-invoice':         { title: 'Factura cerrada', subtitle: 'SVB-00233 · Firmada y cerrada' },
  declarations:             { title: 'Declaraciones SVB', subtitle: 'Generación y exportación de declaraciones' },
  'declaration-validate':   { title: 'Validación de declaración', subtitle: '' },
  production:               { title: 'Producción', subtitle: 'Análisis de facturación y rendimiento' },
  procedures:               { title: 'Procedimientos SVB', subtitle: 'Catálogo de procedimientos y tarifas' },
  professionals:            { title: 'Profesionales', subtitle: 'Gestión de profesionales de la clínica' },
  users:                    { title: 'Usuarios', subtitle: 'Gestión de accesos y roles del sistema' },
  audit:                    { title: 'Auditoría', subtitle: 'Registro completo de acciones del sistema' },
  config:                   { title: 'Configuración', subtitle: 'Configuración SVB y parámetros del sistema' },
}

const defaultPageByRole: Record<Role, Page> = {
  admin: 'admin-dashboard',
  reception: 'reception-dashboard',
  professional: 'professional-dashboard',
}

export default function App() {
  const [role, setRole] = useState<Role | null>(null)
  const [page, setPage] = useState<Page>('login')

  const handleLogin = (r: Role) => {
    setRole(r)
    setPage(defaultPageByRole[r])
  }

  const handleRoleChange = (r: Role) => {
    setRole(r)
    setPage(defaultPageByRole[r])
  }

  const navigate = (p: Page) => setPage(p)

  if (!role || page === 'login') {
    return <LoginPage onLogin={handleLogin} />
  }

  const { title, subtitle } = pageTitles[page] ?? { title: page }

  const renderPage = () => {
    switch (page) {
      case 'admin-dashboard':        return <AdminDashboard onNavigate={navigate} />
      case 'reception-dashboard':    return <ReceptionDashboard onNavigate={navigate} />
      case 'professional-dashboard': return <ProfessionalDashboard onNavigate={navigate} />
      case 'agenda':                 return <AgendaPage onNavigate={navigate} />
      case 'patients':               return <PatientsPage onNavigate={navigate} />
      case 'new-patient':            return <NewPatientPage onNavigate={navigate} />
      case 'patient-detail':         return <PatientsPage onNavigate={navigate} />
      case 'appointment-detail':     return <AppointmentDetailPage onNavigate={navigate} />
      case 'clinical':               return <ClinicalPage onNavigate={navigate} />
      case 'invoices':               return <InvoicesPage onNavigate={navigate} />
      case 'invoice-detail':         return <InvoiceDetailPage onNavigate={navigate} />
      case 'signature':              return <SignaturePage onNavigate={navigate} />
      case 'closed-invoice':         return <ClosedInvoicePage onNavigate={navigate} />
      case 'declarations':           return <SVBDeclarationsPage onNavigate={navigate} />
      case 'production':             return <ProductionPage />
      case 'procedures':             return <ProceduresPage />
      case 'professionals':          return <UsersPage />
      case 'users':                  return <UsersPage />
      case 'audit':                  return <AuditPage />
      case 'config':                 return <ConfigPage />
      default:                       return <AdminDashboard onNavigate={navigate} />
    }
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: '#F4F6F9' }}>
      <Sidebar role={role} currentPage={page} onNavigate={navigate} onRoleChange={handleRoleChange} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header title={title} subtitle={subtitle} />
        <main className="flex-1 overflow-y-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  )
}
