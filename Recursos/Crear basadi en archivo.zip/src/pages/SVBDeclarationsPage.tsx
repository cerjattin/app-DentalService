import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const declarations = [
  { id: 'DEC-2026-08', periodo: 'Agosto 2026', pacientes: 148, procedimientos: 312, total: 38450.00, estado: 'preparacion' as const },
  { id: 'DEC-2026-07', periodo: 'Julio 2026', pacientes: 162, procedimientos: 341, total: 42100.00, estado: 'exportado' as const },
  { id: 'DEC-2026-06', periodo: 'Junio 2026', pacientes: 139, procedimientos: 289, total: 35800.00, estado: 'exportado' as const },
]

const validationResults = [
  { registro: 'SVB-00231 · Carmen Willems', campo: 'Treatment ID', error: null },
  { registro: 'SVB-00229 · Egbert Seferina', campo: 'Provider ID', error: 'Provider ID debe tener exactamente 5 dígitos.' },
  { registro: 'SVB-00227 · Nathalie Pieters', campo: 'SVB ID', error: 'SVB ID debe contener exactamente 9 dígitos.' },
  { registro: 'SVB-00226 · Marcus Davelaar', campo: 'Treatment ID', error: 'Treatment ID supera longitud permitida.' },
  { registro: 'SVB-00225 · Louis Martina', campo: 'Diagnostic code', error: 'Campo obligatorio vacío.' },
]

interface SVBDeclarationsPageProps {
  onNavigate: (page: Page) => void
}

export default function SVBDeclarationsPage({ onNavigate }: SVBDeclarationsPageProps) {
  const [tab, setTab] = useState<'lista' | 'validacion'>('lista')
  const [validating, setValidating] = useState(false)
  const [validated, setValidated] = useState(false)

  const errors = validationResults.filter((r) => r.error)
  const valid = validationResults.filter((r) => !r.error)

  const handleValidate = () => {
    setValidating(true)
    setTimeout(() => {
      setValidating(false)
      setValidated(true)
      setTab('validacion')
    }, 1500)
  }

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 w-fit">
        {(['lista', 'validacion'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              tab === t ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t === 'lista' ? 'Lotes de declaración' : 'Validación de registros'}
          </button>
        ))}
      </div>

      {tab === 'lista' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              className="px-4 py-2 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity"
              style={{ backgroundColor: '#1A6FE8' }}
            >
              + Generar declaración SVB
            </button>
          </div>

          <div className="space-y-3">
            {declarations.map((d) => (
              <div key={d.id} className="bg-white rounded-xl border border-slate-200 p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="text-sm font-semibold text-slate-800">{d.periodo}</div>
                    <div className="text-xs font-mono text-slate-500 mt-0.5">{d.id}</div>
                  </div>
                  <Badge variant={d.estado} />
                </div>
                <div className="grid grid-cols-4 gap-4 mb-4">
                  {[
                    { label: 'Pacientes', value: d.pacientes },
                    { label: 'Procedimientos', value: d.procedimientos },
                    { label: 'Total declarado', value: `ANG ${d.total.toLocaleString('en', { minimumFractionDigits: 2 })}` },
                    { label: 'Declarant ID', value: 'DEC-54321' },
                  ].map((f) => (
                    <div key={f.label}>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">{f.label}</div>
                      <div className="text-sm font-semibold font-mono text-slate-800">{f.value}</div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2 border-t border-slate-100 pt-3">
                  {d.estado === 'preparacion' && (
                    <>
                      <button
                        onClick={handleValidate}
                        disabled={validating}
                        className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg"
                        style={{ backgroundColor: '#1A6FE8' }}
                      >
                        {validating ? 'Validando...' : 'Validar declaración'}
                      </button>
                      <button
                        onClick={() => setTab('validacion')}
                        className="px-3 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg"
                      >
                        Ver validación
                      </button>
                    </>
                  )}
                  {d.estado === 'exportado' && (
                    <>
                      <button className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg" style={{ backgroundColor: '#16A34A' }}>
                        ⬇ CSV
                      </button>
                      <button className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg" style={{ backgroundColor: '#0891B2' }}>
                        ⬇ TXT
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'validacion' && (
        <div className="space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl p-4">
              <span className="text-xl">✓</span>
              <div>
                <div className="text-lg font-bold text-green-800 font-mono">{valid.length} registros válidos</div>
                <div className="text-xs text-green-600">Listos para exportar</div>
              </div>
            </div>
            <div className={`flex items-center gap-3 rounded-xl p-4 border ${errors.length > 0 ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
              <span className="text-xl">{errors.length > 0 ? '⚠' : '✓'}</span>
              <div>
                <div className={`text-lg font-bold font-mono ${errors.length > 0 ? 'text-red-700' : 'text-green-800'}`}>
                  {errors.length} {errors.length > 0 ? 'requieren corrección' : 'errores'}
                </div>
                <div className={`text-xs ${errors.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {errors.length > 0 ? 'No se puede exportar con errores críticos' : 'Sin errores detectados'}
                </div>
              </div>
            </div>
          </div>

          {/* Validation table */}
          <div className="bg-white rounded-xl border border-slate-200">
            <div className="px-5 py-3.5 border-b border-slate-100">
              <h3 className="text-sm font-semibold text-slate-800">Detalle de validación — DEC-2026-08</h3>
            </div>
            <div className="divide-y divide-slate-50">
              {validationResults.map((r, i) => (
                <div key={i} className={`flex items-center gap-4 px-5 py-3 ${r.error ? 'bg-red-50/30' : ''}`}>
                  <span className={r.error ? 'text-red-500' : 'text-green-500'}>{r.error ? '✕' : '✓'}</span>
                  <div className="flex-1">
                    <div className="text-xs font-mono font-medium text-slate-700">{r.registro}</div>
                    {r.error && <div className="text-xs text-red-600 mt-0.5">{r.error}</div>}
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{r.campo}</span>
                  {r.error && (
                    <button className="px-2 py-1 text-[10px] text-amber-700 bg-amber-100 hover:bg-amber-200 rounded transition-colors">
                      Corregir
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Export buttons */}
          <div className="flex items-center gap-3 flex-wrap">
            <button
              disabled={errors.length > 0}
              className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
              style={{ backgroundColor: '#16A34A' }}
            >
              Generar CSV
            </button>
            <button
              disabled={errors.length > 0}
              className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
              style={{ backgroundColor: '#0891B2' }}
            >
              Generar TXT
            </button>
            <button
              disabled={errors.length > 0}
              className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
              style={{ backgroundColor: '#1A6FE8' }}
            >
              ⬇ Descargar archivo
            </button>
            {errors.length > 0 && (
              <span className="text-xs text-red-500">
                Corrija los {errors.length} errores antes de exportar.
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
