import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const events = [
  { id: 1, hora: '08:00', dur: 30, paciente: 'Carmen Willems', prof: 'Dr. Pérez', motivo: 'Limpieza', estado: 'cerrada' as const, color: '#16A34A' },
  { id: 2, hora: '08:30', dur: 45, paciente: 'Roberto Cijntje', prof: 'Dra. Gómez', motivo: 'Extracción', estado: 'cerrada' as const, color: '#16A34A' },
  { id: 3, hora: '09:00', dur: 30, paciente: 'Marisela Hato', prof: 'Dr. Pérez', motivo: 'Consulta', estado: 'atencion' as const, color: '#4F46E5' },
  { id: 4, hora: '09:30', dur: 40, paciente: 'Louis Martina', prof: 'Dr. Ríos', motivo: 'Obturación', estado: 'espera' as const, color: '#D97706' },
  { id: 5, hora: '10:00', dur: 60, paciente: 'Jolanda Bikker', prof: 'Dra. Gómez', motivo: 'Periodoncia', estado: 'checkin' as const, color: '#1A6FE8' },
  { id: 6, hora: '11:00', dur: 30, paciente: 'Egbert Seferina', prof: 'Dr. Pérez', motivo: 'Revisión', estado: 'programada' as const, color: '#94A3B8' },
  { id: 7, hora: '14:00', dur: 30, paciente: 'Nathalie Pieters', prof: 'Dr. Ríos', motivo: 'Extracción', estado: 'programada' as const, color: '#94A3B8' },
  { id: 8, hora: '15:00', dur: 45, paciente: 'Marcus Davelaar', prof: 'Dra. Gómez', motivo: 'Corona', estado: 'programada' as const, color: '#94A3B8' },
]

const hours = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00']

interface AgendaPageProps {
  onNavigate: (page: Page) => void
}

export default function AgendaPage({ onNavigate }: AgendaPageProps) {
  const [mode, setMode] = useState<'dia' | 'lista'>('dia')
  const [prof, setProf] = useState('todos')
  const [selected, setSelected] = useState<typeof events[0] | null>(null)

  const filtered = events.filter((e) => prof === 'todos' || e.prof.includes(prof))

  return (
    <div className="p-6 space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1">
          {(['dia', 'lista'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${mode === m ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              {m === 'dia' ? 'Día' : 'Lista'}
            </button>
          ))}
        </div>
        <select
          value={prof}
          onChange={(e) => setProf(e.target.value)}
          className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none"
        >
          <option value="todos">Todos los profesionales</option>
          <option value="Pérez">Dr. Pérez</option>
          <option value="Gómez">Dra. Gómez</option>
          <option value="Ríos">Dr. Ríos</option>
        </select>
        <div className="flex items-center gap-2 ml-auto">
          <button className="px-3 py-2 text-xs text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50">‹ Ayer</button>
          <span className="text-sm font-semibold text-slate-700">Martes 12 de agosto, 2026</span>
          <button className="px-3 py-2 text-xs text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50">Mañana ›</button>
        </div>
        <button
          className="px-4 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-90"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          + Nueva cita
        </button>
      </div>

      {mode === 'dia' && (
        <div className="flex gap-4">
          {/* Timeline */}
          <div className="bg-white rounded-xl border border-slate-200 flex-1 overflow-hidden">
            <div className="overflow-y-auto" style={{ maxHeight: '600px' }}>
              {hours.map((h) => {
                const eventsAtHour = filtered.filter((e) => e.hora.startsWith(h.split(':')[0]))
                return (
                  <div key={h} className="flex border-b border-slate-100 last:border-b-0">
                    <div className="w-16 flex-shrink-0 px-3 py-3 text-xs font-mono text-slate-400 border-r border-slate-100">{h}</div>
                    <div className="flex-1 px-2 py-2 min-h-12">
                      {eventsAtHour.map((ev) => (
                        <button
                          key={ev.id}
                          onClick={() => setSelected(ev)}
                          className="w-full text-left mb-1 px-3 py-2 rounded-lg border transition-all hover:shadow-sm"
                          style={{ backgroundColor: `${ev.color}15`, borderColor: `${ev.color}40` }}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-semibold" style={{ color: ev.color }}>{ev.hora} · {ev.paciente}</span>
                              <span className="text-[11px] text-slate-500 ml-2">{ev.motivo}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] text-slate-400">{ev.prof}</span>
                              <Badge variant={ev.estado} size="sm" />
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Detail panel */}
          {selected && (
            <div className="w-64 flex-shrink-0">
              <div className="bg-white rounded-xl border border-slate-200 p-5 sticky top-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-slate-800">Detalle de cita</h3>
                  <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600 text-sm">✕</button>
                </div>
                <div className="space-y-3">
                  {[
                    { label: 'Paciente', value: selected.paciente },
                    { label: 'Hora', value: selected.hora },
                    { label: 'Duración', value: `${selected.dur} min` },
                    { label: 'Profesional', value: selected.prof },
                    { label: 'Motivo', value: selected.motivo },
                  ].map((f) => (
                    <div key={f.label}>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">{f.label}</div>
                      <div className="text-sm font-medium text-slate-700 mt-0.5">{f.value}</div>
                    </div>
                  ))}
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Estado</div>
                    <div className="mt-1"><Badge variant={selected.estado} /></div>
                  </div>
                </div>
                <div className="mt-5 space-y-2">
                  <button
                    onClick={() => onNavigate('appointment-detail')}
                    className="w-full py-2 text-xs font-semibold text-white rounded-lg"
                    style={{ backgroundColor: '#1A6FE8' }}
                  >
                    Ver detalle completo
                  </button>
                  {(selected.estado === 'espera' || selected.estado === 'atencion') && (
                    <button
                      onClick={() => onNavigate('clinical')}
                      className="w-full py-2 text-xs font-semibold text-white rounded-lg"
                      style={{ backgroundColor: '#16A34A' }}
                    >
                      Iniciar / continuar atención
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {mode === 'lista' && (
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100">
                  {['Hora', 'Paciente', 'Profesional', 'Duración', 'Motivo', 'Estado', 'Acción'].map((h) => (
                    <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-4 py-3 text-xs font-mono font-semibold text-slate-700">{ev.hora}</td>
                    <td className="px-4 py-3 text-sm font-medium text-slate-700">{ev.paciente}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">{ev.prof}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">{ev.dur} min</td>
                    <td className="px-4 py-3 text-xs text-slate-600">{ev.motivo}</td>
                    <td className="px-4 py-3"><Badge variant={ev.estado} size="sm" /></td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => onNavigate('appointment-detail')}
                        className="px-3 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md"
                      >
                        Ver
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
