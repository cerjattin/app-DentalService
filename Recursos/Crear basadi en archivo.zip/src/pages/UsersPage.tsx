import { useState } from 'react'
import Badge from '../components/Badge'

const users = [
  { id: 'USR-001', nombre: 'Admin General', usuario: 'admin', rol: 'admin' as const, profesional: '—', estado: 'activo' as const, ultimoAcceso: '12/08/2026 10:32' },
  { id: 'USR-002', nombre: 'María Recepción', usuario: 'recepcion', rol: 'recepcion' as const, profesional: '—', estado: 'activo' as const, ultimoAcceso: '12/08/2026 08:05' },
  { id: 'USR-003', nombre: 'Dr. Juan Pérez', usuario: 'dr.perez', rol: 'profesional' as const, profesional: 'Dr. Juan Pérez', estado: 'activo' as const, ultimoAcceso: '12/08/2026 08:30' },
  { id: 'USR-004', nombre: 'Dra. María Gómez', usuario: 'dra.gomez', rol: 'profesional' as const, profesional: 'Dra. María Gómez', estado: 'activo' as const, ultimoAcceso: '12/08/2026 09:00' },
  { id: 'USR-005', nombre: 'Dr. Carlos Ríos', usuario: 'dr.rios', rol: 'profesional' as const, profesional: 'Dr. Carlos Ríos', estado: 'activo' as const, ultimoAcceso: '11/08/2026 17:55' },
  { id: 'USR-006', nombre: 'Ana Martínez', usuario: 'ana.martinez', rol: 'recepcion' as const, profesional: '—', estado: 'inactivo' as const, ultimoAcceso: '05/07/2026 11:20' },
]

const rolColor: Record<string, string> = { admin: 'admin', recepcion: 'recepcion', profesional: 'profesional' }

export default function UsersPage() {
  const [search, setSearch] = useState('')

  const filtered = users.filter(
    (u) =>
      !search ||
      u.nombre.toLowerCase().includes(search.toLowerCase()) ||
      u.usuario.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar usuario..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
        </div>
        <button className="px-4 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-90" style={{ backgroundColor: '#1A6FE8' }}>
          + Crear usuario
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Nombre', 'Usuario', 'Rol', 'Profesional asociado', 'Estado', 'Último acceso', 'Acciones'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold text-white"
                        style={{ backgroundColor: u.estado === 'activo' ? '#1A6FE8' : '#94A3B8' }}
                      >
                        {u.nombre.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                      </div>
                      <span className="text-sm font-medium text-slate-700">{u.nombre}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-600">{u.usuario}</td>
                  <td className="px-4 py-3">
                    <Badge variant={rolColor[u.rol] as any} size="sm" />
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">{u.profesional}</td>
                  <td className="px-4 py-3"><Badge variant={u.estado} size="sm" /></td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-400">{u.ultimoAcceso}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="px-2 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md">Editar</button>
                      <button className="px-2 py-1 text-xs text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md">Resetear pw</button>
                      <button className={`px-2 py-1 text-xs rounded-md ${u.estado === 'activo' ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-green-600 bg-green-50 hover:bg-green-100'}`}>
                        {u.estado === 'activo' ? 'Desactivar' : 'Activar'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
