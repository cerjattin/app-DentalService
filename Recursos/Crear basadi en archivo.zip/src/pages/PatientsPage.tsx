import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const patients = [
  { id: 'PAC-001', nombre: 'Carmen Willems', svb: '123456789', dob: '12/03/1985', tel: '+599 9 567-1234', estado: 'activo' as const, ultimaCita: '12/08/2026' },
  { id: 'PAC-002', nombre: 'Roberto Cijntje', svb: '234567890', dob: '05/07/1972', tel: '+599 9 678-2345', estado: 'activo' as const, ultimaCita: '11/08/2026' },
  { id: 'PAC-003', nombre: 'Marisela Hato', svb: '345678901', dob: '22/11/1990', tel: '+599 9 789-3456', estado: 'activo' as const, ultimaCita: '12/08/2026' },
  { id: 'PAC-004', nombre: 'Louis Martina', svb: '456789012', dob: '30/01/1965', tel: '+599 9 890-4567', estado: 'activo' as const, ultimaCita: '10/08/2026' },
  { id: 'PAC-005', nombre: 'Jolanda Bikker', svb: '567890123', dob: '18/09/1988', tel: '+599 9 901-5678', estado: 'activo' as const, ultimaCita: '12/08/2026' },
  { id: 'PAC-006', nombre: 'Egbert Seferina', svb: '678901234', dob: '07/04/1958', tel: '+599 9 012-6789', estado: 'inactivo' as const, ultimaCita: '15/06/2026' },
  { id: 'PAC-007', nombre: 'Nathalie Pieters', svb: '789012345', dob: '14/06/2001', tel: '+599 9 123-7890', estado: 'activo' as const, ultimaCita: '01/08/2026' },
  { id: 'PAC-008', nombre: 'Marcus Davelaar', svb: '890123456', dob: '25/12/1980', tel: '+599 9 234-8901', estado: 'activo' as const, ultimaCita: '05/08/2026' },
]

interface PatientsPageProps {
  onNavigate: (page: Page) => void
}

export default function PatientsPage({ onNavigate }: PatientsPageProps) {
  const [searchQ, setSearchQ] = useState('')
  const [filter, setFilter] = useState('todos')

  const filtered = patients.filter((p) => {
    const matchQ = !searchQ ||
      p.nombre.toLowerCase().includes(searchQ.toLowerCase()) ||
      p.svb.includes(searchQ) ||
      p.id.toLowerCase().includes(searchQ.toLowerCase())
    const matchF = filter === 'todos' || p.estado === filter
    return matchQ && matchF
  })

  return (
    <div className="p-6 space-y-5">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <input
            type="text"
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            placeholder="Buscar por nombre, SVB Card, ID paciente..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
        </div>
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1">
          {['todos', 'activo', 'inactivo'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${
                filter === f ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
        <button
          onClick={() => onNavigate('new-patient')}
          className="px-4 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-90 transition-opacity"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          + Nuevo paciente
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-800">Pacientes registrados</h3>
          <span className="text-xs text-slate-400">{filtered.length} de {patients.length} resultados</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['ID', 'Paciente', 'SVB Card', 'Fecha nac.', 'Teléfono', 'Estado', 'Última cita', 'Acciones'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{p.id}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold text-white"
                        style={{ backgroundColor: p.estado === 'activo' ? '#1A6FE8' : '#94A3B8' }}
                      >
                        {p.nombre.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                      </div>
                      <button
                        onClick={() => onNavigate('patient-detail')}
                        className="text-sm font-medium text-blue-600 hover:underline"
                      >
                        {p.nombre}
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-600">{p.svb}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{p.dob}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{p.tel}</td>
                  <td className="px-4 py-3"><Badge variant={p.estado} size="sm" /></td>
                  <td className="px-4 py-3 text-xs text-slate-500">{p.ultimaCita}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onNavigate('patient-detail')}
                        className="px-2.5 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        Ver
                      </button>
                      <button
                        onClick={() => onNavigate('new-patient')}
                        className="px-2.5 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => onNavigate('agenda')}
                        className="px-2.5 py-1 text-xs text-white rounded-md transition-colors"
                        style={{ backgroundColor: '#1A6FE8' }}
                      >
                        Nueva cita
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-400">Mostrando {filtered.length} resultados</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3].map((pg) => (
              <button
                key={pg}
                className={`w-7 h-7 text-xs rounded-md transition-all ${pg === 1 ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                {pg}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
