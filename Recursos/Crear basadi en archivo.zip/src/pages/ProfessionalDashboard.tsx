import Badge from '../components/Badge'
import type { Page } from '../types'

const agenda = [
  { id: 1, hora: '08:00', paciente: 'Carmen Willems', svb: '123456789', motivo: 'Limpieza dental', estado: 'cerrada' as const, dur: '30 min' },
  { id: 2, hora: '09:00', paciente: 'Roberto Cijntje', svb: '234567890', motivo: 'Extracción molar', estado: 'cerrada' as const, dur: '45 min' },
  { id: 3, hora: '10:00', paciente: 'Marisela Hato', svb: '345678901', motivo: 'Consulta general', estado: 'atencion' as const, dur: '30 min' },
  { id: 4, hora: '11:00', paciente: 'Louis Martina', svb: '456789012', motivo: 'Obturación compuesta', estado: 'espera' as const, dur: '40 min' },
  { id: 5, hora: '12:00', paciente: 'Jolanda Bikker', svb: '567890123', motivo: 'Periodoncia', estado: 'programada' as const, dur: '60 min' },
  { id: 6, hora: '14:00', paciente: 'Egbert Seferina', svb: '678901234', motivo: 'Revisión', estado: 'programada' as const, dur: '20 min' },
]

interface ProfessionalDashboardProps {
  onNavigate: (page: Page) => void
}

export default function ProfessionalDashboard({ onNavigate }: ProfessionalDashboardProps) {
  const waiting = agenda.filter((a) => a.estado === 'espera')
  const inProgress = agenda.find((a) => a.estado === 'atencion')

  return (
    <div className="p-6 space-y-5">
      {/* In progress alert */}
      {inProgress && (
        <div
          className="rounded-xl border p-4 flex items-center gap-4"
          style={{ backgroundColor: '#EEF2FF', borderColor: '#C7D2FE' }}
        >
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
            style={{ backgroundColor: '#4F46E5' }}
          >
            ⏱
          </div>
          <div className="flex-1">
            <div className="text-sm font-semibold text-indigo-900">En atención ahora</div>
            <div className="text-sm text-indigo-700">{inProgress.paciente} — {inProgress.motivo}</div>
            <div className="text-xs text-indigo-500 font-mono">{inProgress.hora} · SVB {inProgress.svb}</div>
          </div>
          <button
            onClick={() => onNavigate('clinical')}
            className="px-4 py-2 text-sm font-semibold text-white rounded-lg"
            style={{ backgroundColor: '#4F46E5' }}
          >
            Abrir atención
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Pacientes atendidos', value: '2', color: '#16A34A' },
          { label: 'En espera', value: waiting.length.toString(), color: '#D97706' },
          { label: 'Programados', value: agenda.filter((a) => a.estado === 'programada').length.toString(), color: '#1A6FE8' },
          { label: 'Producción hoy', value: 'ANG 1,240', color: '#7C3AED' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-xl font-bold font-mono mb-0.5" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Waiting patients */}
      {waiting.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-800">Pacientes esperando</h3>
            <span className="text-xs font-mono font-bold text-amber-600 bg-amber-100 px-2 py-0.5 rounded-full">{waiting.length}</span>
          </div>
          <div className="divide-y divide-slate-50">
            {waiting.map((p) => (
              <div key={p.id} className="px-5 py-3.5 flex items-center gap-4 hover:bg-slate-50/50 transition-colors">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-semibold"
                  style={{ backgroundColor: '#D97706' }}
                >
                  {p.paciente.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-slate-700">{p.paciente}</div>
                  <div className="text-xs text-slate-500">{p.motivo} · <span className="font-mono">{p.hora}</span></div>
                </div>
                <Badge variant="espera" size="sm" />
                <button
                  onClick={() => onNavigate('clinical')}
                  className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg"
                  style={{ backgroundColor: '#1A6FE8' }}
                >
                  Iniciar atención
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Full agenda */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-3.5 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-slate-800">Mi agenda — hoy</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Hora', 'Paciente', 'SVB Card', 'Motivo', 'Duración', 'Estado', 'Acción'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {agenda.map((a) => (
                <tr key={a.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-3 text-xs font-mono font-medium text-slate-600">{a.hora}</td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-700">{a.paciente}</td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{a.svb}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{a.motivo}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.dur}</td>
                  <td className="px-4 py-3"><Badge variant={a.estado} size="sm" /></td>
                  <td className="px-4 py-3">
                    {(a.estado === 'espera' || a.estado === 'atencion') && (
                      <button
                        onClick={() => onNavigate('clinical')}
                        className="px-3 py-1 text-xs font-semibold text-white rounded-lg"
                        style={{ backgroundColor: '#1A6FE8' }}
                      >
                        {a.estado === 'atencion' ? 'Continuar' : 'Iniciar'}
                      </button>
                    )}
                    {a.estado === 'cerrada' && (
                      <span className="text-xs text-slate-400">Completada</span>
                    )}
                    {a.estado === 'programada' && (
                      <span className="text-xs text-slate-400">Próximamente</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
