import { useState } from 'react'

export default function ConfigPage() {
  const [form, setForm] = useState({
    declarantId: 'DEC-54321',
    clinicaNombre: 'OdonthoServices',
    clinicaDireccion: 'Willemstad, Curaçao',
    clinicaTel: '+599 9 500-0000',
    prefijoFactura: 'SVB',
    secuenciaFactura: '234',
    formatoDetail: 'SVB-{SEQ6}',
    exportFormato: 'CSV',
    pdfOrientation: 'portrait',
  })

  const update = (field: string, val: string) => setForm((f) => ({ ...f, [field]: val }))

  return (
    <div className="p-6 max-w-3xl space-y-5">
      {/* SVB Global */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Configuración SVB</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Declarant ID</label>
            <input
              type="text"
              value={form.declarantId}
              onChange={(e) => update('declarantId', e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Formato exportación</label>
            <select
              value={form.exportFormato}
              onChange={(e) => update('exportFormato', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            >
              <option>CSV</option>
              <option>TXT</option>
              <option>Ambos</option>
            </select>
          </div>
        </div>
      </div>

      {/* Clinic data */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Datos de la clínica</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Nombre de la clínica', field: 'clinicaNombre' },
            { label: 'Teléfono', field: 'clinicaTel' },
            { label: 'Dirección', field: 'clinicaDireccion' },
          ].map(({ label, field }) => (
            <div key={field} className={field === 'clinicaDireccion' ? 'col-span-2' : ''}>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">{label}</label>
              <input
                type="text"
                value={form[field as keyof typeof form]}
                onChange={(e) => update(field, e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Invoice numbering */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Numeración de facturas</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Prefijo de factura', field: 'prefijoFactura' },
            { label: 'Secuencia actual', field: 'secuenciaFactura' },
            { label: 'Formato Detail Invoice', field: 'formatoDetail' },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">{label}</label>
              <input
                type="text"
                value={form[field as keyof typeof form]}
                onChange={(e) => update(field, e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          ))}
        </div>
        <div className="mt-3 px-3 py-2 bg-blue-50 rounded-lg">
          <p className="text-xs text-blue-700">
            Próxima factura: <span className="font-mono font-bold">SVB-000234</span>
          </p>
        </div>
      </div>

      {/* PDF */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Configuración PDF</h3>
        <div>
          <label className="block text-xs font-medium text-slate-600 mb-1.5">Orientación de página</label>
          <div className="flex gap-3">
            {['portrait', 'landscape'].map((o) => (
              <button
                key={o}
                onClick={() => update('pdfOrientation', o)}
                className={`px-4 py-2 text-sm rounded-lg border transition-all ${
                  form.pdfOrientation === o
                    ? 'border-blue-500 bg-blue-50 text-blue-700 font-semibold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {o === 'portrait' ? '📄 Vertical' : '📃 Horizontal'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Save */}
      <div className="flex justify-end gap-3 pb-4">
        <button className="px-5 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50">
          Cancelar
        </button>
        <button
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          Guardar configuración
        </button>
      </div>
    </div>
  )
}
