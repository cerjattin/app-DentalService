import type { Page } from '../types'

interface InvoiceDetailPageProps {
  onNavigate: (page: Page) => void
}

const procedures = [
  { datum: '12/08/2026', code: 'T001', omsch: 'Consulta y examen dental', macht: '', aantal: 1, assist: 'N', poli: 'P', bedrag: 85.00, opmerking: '' },
  { datum: '12/08/2026', code: 'T003', omsch: 'Limpieza dental (profilaxis)', macht: '', aantal: 1, assist: 'N', poli: 'P', bedrag: 120.00, opmerking: '' },
  { datum: '12/08/2026', code: 'T004', omsch: 'Obturación (amalgama 1 superficie)', macht: 'AUT-2891', aantal: 2, assist: 'Y', poli: 'P', bedrag: 190.00, opmerking: 'Premolar inferior' },
]

const total = procedures.reduce((s, p) => s + p.bedrag, 0)

export default function InvoiceDetailPage({ onNavigate }: InvoiceDetailPageProps) {
  return (
    <div className="p-6 max-w-4xl space-y-5">
      {/* Preview header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-slate-800">Vista previa — Factura SVB</h2>
          <p className="text-xs text-slate-500">Revise los datos antes de solicitar la firma del paciente.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('invoices')}
            className="px-3 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            Volver
          </button>
          <button
            onClick={() => onNavigate('signature')}
            className="px-4 py-2 text-xs font-semibold text-white rounded-lg"
            style={{ backgroundColor: '#D97706' }}
          >
            Solicitar firma →
          </button>
        </div>
      </div>

      {/* SVB Notaformulier */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200" style={{ backgroundColor: '#0B1F3A' }}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white tracking-wide">SVB Notaformulier</h3>
              <p className="text-white/50 text-xs font-mono">Sociale Verzekeringsbank Curaçao</p>
            </div>
            <div className="text-white/80 text-xs font-mono text-right">
              <div>OdonthoServices</div>
              <div className="text-white/50">Willemstad, Curaçao</div>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Patient/invoice info grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-4 mb-6 pb-6 border-b border-slate-100">
            {[
              { label: 'Naam SVB-verzekerde', value: 'Hato, Marisela' },
              { label: 'SVB Seguro Cardnr', value: '345678901', mono: true },
              { label: 'Detail factuurnummer', value: 'SVB-00233', mono: true },
              { label: 'OMF-nummer', value: '—' },
              { label: 'Diagnosecode', value: 'K02.1 — Caries dentinaria', mono: true },
              { label: 'Code & naam verwijzend arts', value: 'DOC-4521 · Dr. Ramírez' },
            ].map((f) => (
              <div key={f.label}>
                <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-0.5">{f.label}</div>
                <div className={`text-sm text-slate-800 ${f.mono ? 'font-mono' : 'font-medium'}`}>{f.value}</div>
              </div>
            ))}
          </div>

          {/* Procedures table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b-2 border-slate-200">
                  {['Datum', 'Verrichtingscode', 'Omschrijving', 'Macht-nummer', 'Aantal', 'Assist. J/N', 'Poli/Klin. P/K', 'Bedrag', 'Opmerkingen'].map((h) => (
                    <th key={h} className="text-left font-semibold text-slate-600 pb-2 pr-3 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {procedures.map((p, i) => (
                  <tr key={i} className="hover:bg-slate-50/50">
                    <td className="py-2.5 pr-3 font-mono text-slate-600">{p.datum}</td>
                    <td className="py-2.5 pr-3 font-mono font-bold text-blue-700">{p.code}</td>
                    <td className="py-2.5 pr-3 text-slate-700">{p.omsch}</td>
                    <td className="py-2.5 pr-3 font-mono text-slate-500">{p.macht || '—'}</td>
                    <td className="py-2.5 pr-3 font-mono text-center">{p.aantal}</td>
                    <td className="py-2.5 pr-3 font-mono text-center">{p.assist}</td>
                    <td className="py-2.5 pr-3 font-mono text-center">{p.poli}</td>
                    <td className="py-2.5 pr-3 font-mono font-semibold text-slate-800 text-right">ANG {p.bedrag.toFixed(2)}</td>
                    <td className="py-2.5 text-slate-500 text-[11px]">{p.opmerking || '—'}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-300">
                  <td colSpan={7} className="pt-3 font-bold text-slate-700 text-right pr-3">Totaal bedrag:</td>
                  <td className="pt-3 font-mono font-bold text-slate-900 text-right">ANG {total.toFixed(2)}</td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Professional footer */}
          <div className="mt-6 pt-4 border-t border-slate-200 flex justify-between items-end">
            <div>
              <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Code en naam medewerkende</div>
              <div className="text-sm font-semibold text-slate-800">PRV-00142 · Dr. Juan Pérez</div>
              <div className="text-xs text-slate-500">Odontólogo — OdonthoServices</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Paraaf / Firma</div>
              <div className="w-40 h-14 border border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-400 text-xs">
                Pendiente firma
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={() => onNavigate('signature')}
          className="px-6 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity"
          style={{ backgroundColor: '#D97706' }}
        >
          Capturar firma del paciente →
        </button>
      </div>
    </div>
  )
}
