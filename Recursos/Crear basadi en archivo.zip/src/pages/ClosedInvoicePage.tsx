import type { Page } from '../types'

interface ClosedInvoicePageProps {
  onNavigate: (page: Page) => void
}

export default function ClosedInvoicePage({ onNavigate }: ClosedInvoicePageProps) {
  return (
    <div className="p-6 max-w-2xl space-y-5">
      {/* Success */}
      <div className="bg-white rounded-2xl border border-green-200 p-6 text-center" style={{ backgroundColor: '#F0FDF4' }}>
        <div
          className="w-14 h-14 rounded-full flex items-center justify-center text-2xl mx-auto mb-3"
          style={{ backgroundColor: '#DCFCE7' }}
        >
          ✓
        </div>
        <h2 className="text-lg font-bold text-green-800 mb-1">Factura cerrada</h2>
        <p className="text-sm text-green-600">La factura ha sido firmada y cerrada correctamente.</p>
      </div>

      {/* Invoice info */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Información de la factura</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Número de factura', value: 'SVB-00233', mono: true },
            { label: 'Paciente', value: 'Marisela Hato' },
            { label: 'Fecha de atención', value: '12/08/2026' },
            { label: 'Profesional', value: 'Dr. Juan Pérez' },
            { label: 'Total', value: 'ANG 395.00', mono: true },
            { label: 'Estado', value: 'Cerrada' },
            { label: 'Firma registrada', value: 'Sí — Digital' },
            { label: 'Fecha/hora de firma', value: '12/08/2026 — 10:47 AM' },
          ].map((f) => (
            <div key={f.label}>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">{f.label}</div>
              <div className={`text-sm font-semibold text-slate-800 ${f.mono ? 'font-mono' : ''}`}>{f.value}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-slate-100">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2">Vista previa de firma capturada</div>
          <div className="h-16 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center">
            <div className="text-slate-300 text-xs italic">Firma digital registrada</div>
          </div>
        </div>
      </div>

      {/* Warning */}
      <div className="flex items-start gap-3 px-4 py-3 bg-amber-50 border border-amber-200 rounded-lg">
        <span className="text-amber-500 text-sm mt-0.5">⚠</span>
        <p className="text-xs text-amber-700 leading-relaxed">
          Esta factura está cerrada y no puede modificarse directamente. Si requiere corrección, contacte al administrador del sistema.
        </p>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3 flex-wrap">
        <button
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          👁 Ver PDF
        </button>
        <button
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2"
          style={{ backgroundColor: '#0B1F3A' }}
        >
          ⬇ Descargar PDF
        </button>
        <button
          className="px-5 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2"
        >
          🖨 Imprimir
        </button>
        <button
          onClick={() => onNavigate('reception-dashboard')}
          className="px-5 py-2.5 text-sm font-medium text-slate-500 hover:text-slate-700 transition-colors"
        >
          Volver al inicio
        </button>
      </div>
    </div>
  )
}
