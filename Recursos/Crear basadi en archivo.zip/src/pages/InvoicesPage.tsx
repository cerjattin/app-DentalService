import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const invoices = [
  { num: 'SVB-00233', paciente: 'Marisela Hato', svb: '345678901', fecha: '12/08/2026', prof: 'Dr. Pérez', total: 395.00, estado: 'pendiente-firma' as const },
  { num: 'SVB-00232', paciente: 'Roberto Cijntje', svb: '234567890', fecha: '12/08/2026', prof: 'Dra. Gómez', total: 510.00, estado: 'firmada' as const },
  { num: 'SVB-00231', paciente: 'Carmen Willems', svb: '123456789', fecha: '12/08/2026', prof: 'Dr. Pérez', total: 205.00, estado: 'cerrada' as const },
  { num: 'SVB-00230', paciente: 'Louis Martina', svb: '456789012', fecha: '11/08/2026', prof: 'Dr. Ríos', total: 650.00, estado: 'declarada' as const },
  { num: 'SVB-00229', paciente: 'Egbert Seferina', svb: '678901234', fecha: '10/08/2026', prof: 'Dr. Pérez', total: 85.00, estado: 'anulada' as const },
  { num: 'SVB-00228', paciente: 'Marcus Davelaar', svb: '890123456', fecha: '09/08/2026', prof: 'Dra. Gómez', total: 1200.00, estado: 'declarada' as const },
  { num: 'SVB-00227', paciente: 'Nathalie Pieters', svb: '789012345', fecha: '08/08/2026', prof: 'Dr. Ríos', total: 320.00, estado: 'cerrada' as const },
]

interface InvoicesPageProps {
  onNavigate: (page: Page) => void
}

export default function InvoicesPage({ onNavigate }: InvoicesPageProps) {
  const [search, setSearch] = useState('')
  const [filterEstado, setFilterEstado] = useState('todos')

  const filtered = invoices.filter((i) => {
    const matchQ = !search ||
      i.num.toLowerCase().includes(search.toLowerCase()) ||
      i.paciente.toLowerCase().includes(search.toLowerCase()) ||
      i.svb.includes(search)
    const matchE = filterEstado === 'todos' || i.estado === filterEstado
    return matchQ && matchE
  })

  const totalFiltered = filtered.reduce((s, i) => s + i.total, 0)

  return (
    <div className="p-6 space-y-5">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por número, paciente, SVB Card..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
        </div>
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1 flex-wrap">
          {['todos', 'borrador', 'pendiente-firma', 'firmada', 'cerrada', 'declarada', 'anulada'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterEstado(f)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                filterEstado === f ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {f === 'todos' ? 'Todos' : f === 'pendiente-firma' ? 'Pend. firma' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <input type="date" className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none" />
          <select className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none">
            <option>Todos los profesionales</option>
            <option>Dr. Pérez</option>
            <option>Dra. Gómez</option>
          </select>
        </div>
      </div>

      {/* Stats strip */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Pendientes firma', value: invoices.filter((i) => i.estado === 'pendiente-firma').length, color: '#D97706' },
          { label: 'Cerradas', value: invoices.filter((i) => i.estado === 'cerrada').length, color: '#16A34A' },
          { label: 'Declaradas', value: invoices.filter((i) => i.estado === 'declarada').length, color: '#7C3AED' },
          { label: 'Total filtrado', value: `ANG ${totalFiltered.toLocaleString('en', { minimumFractionDigits: 2 })}`, color: '#1A6FE8' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-lg font-bold font-mono" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Factura', 'Paciente', 'SVB Card', 'Fecha', 'Profesional', 'Total', 'Estado', 'Acciones'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((inv) => (
                <tr key={inv.num} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-mono font-bold text-blue-700">{inv.num}</td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-700">{inv.paciente}</td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{inv.svb}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{inv.fecha}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{inv.prof}</td>
                  <td className="px-4 py-3 text-sm font-mono font-semibold text-slate-800">
                    ANG {inv.total.toFixed(2)}
                  </td>
                  <td className="px-4 py-3"><Badge variant={inv.estado} size="sm" /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onNavigate('invoice-detail')}
                        className="px-2.5 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        Ver
                      </button>
                      {inv.estado === 'pendiente-firma' && (
                        <button
                          onClick={() => onNavigate('signature')}
                          className="px-2.5 py-1 text-xs text-white bg-orange-500 hover:bg-orange-600 rounded-md transition-colors"
                        >
                          Firmar
                        </button>
                      )}
                      {inv.estado === 'cerrada' && (
                        <button
                          onClick={() => onNavigate('closed-invoice')}
                          className="px-2.5 py-1 text-xs text-white rounded-md transition-colors"
                          style={{ backgroundColor: '#1A6FE8' }}
                        >
                          PDF
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-sm text-slate-400">
                    No hay facturas que coincidan con los filtros aplicados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
