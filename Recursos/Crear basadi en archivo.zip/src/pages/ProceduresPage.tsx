import { useState } from 'react'
import Badge from '../components/Badge'

const procedures = [
  { code: 'T001', name: 'Consulta y examen dental', desc: 'Examen clínico general', tarifa: 85.00, autorizacion: false, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T002', name: 'Radiografía periapical', desc: 'Imagen radiológica periapical', tarifa: 45.00, autorizacion: false, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T003', name: 'Limpieza dental (profilaxis)', desc: 'Detartraje y profilaxis dental', tarifa: 120.00, autorizacion: false, estado: 'activo' as const, actualizado: '15/07/2026' },
  { code: 'T006', name: 'Extracción simple', desc: 'Extracción dental simple', tarifa: 130.00, autorizacion: false, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T007', name: 'Extracción quirúrgica', desc: 'Extracción con elevación de colgajo', tarifa: 220.00, autorizacion: true, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T008', name: 'Tratamiento de conducto', desc: 'Endodoncia unirradicular', tarifa: 380.00, autorizacion: true, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T009', name: 'Corona metal-cerámica', desc: 'Prótesis fija metal-cerámica', tarifa: 650.00, autorizacion: true, estado: 'activo' as const, actualizado: '01/08/2026' },
  { code: 'T015', name: 'Blanqueamiento dental', desc: 'Blanqueamiento profesional', tarifa: 280.00, autorizacion: false, estado: 'inactivo' as const, actualizado: '10/06/2026' },
]

export default function ProceduresPage() {
  const [search, setSearch] = useState('')
  const [filterAuth, setFilterAuth] = useState('todos')

  const filtered = procedures.filter((p) => {
    const matchQ = !search ||
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.name.toLowerCase().includes(search.toLowerCase())
    const matchA = filterAuth === 'todos' ||
      (filterAuth === 'autoriza' ? p.autorizacion : !p.autorizacion)
    return matchQ && matchA
  })

  return (
    <div className="p-6 space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por código o nombre..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
        </div>
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1">
          {['todos', 'autoriza', 'no-autoriza'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterAuth(f)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${filterAuth === f ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              {f === 'todos' ? 'Todos' : f === 'autoriza' ? 'Req. autorización' : 'Sin autorización'}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button className="px-3 py-2 text-xs text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50">⬆ Importar catálogo</button>
          <button className="px-3 py-2 text-xs text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50">⬇ Exportar catálogo</button>
          <button className="px-4 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-90" style={{ backgroundColor: '#1A6FE8' }}>+ Crear procedimiento</button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Código', 'Procedimiento', 'Descripción', 'Tarifa', 'Req. autorización', 'Estado', 'Actualizado', 'Acciones'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((p) => (
                <tr key={p.code} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-mono font-bold text-blue-700">{p.code}</td>
                  <td className="px-4 py-3 text-sm font-medium text-slate-700">{p.name}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{p.desc}</td>
                  <td className="px-4 py-3 text-sm font-mono font-semibold text-slate-800">ANG {p.tarifa.toFixed(2)}</td>
                  <td className="px-4 py-3">
                    {p.autorizacion ? (
                      <span className="text-xs font-medium text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">Sí</span>
                    ) : (
                      <span className="text-xs text-slate-400">No</span>
                    )}
                  </td>
                  <td className="px-4 py-3"><Badge variant={p.estado} size="sm" /></td>
                  <td className="px-4 py-3 text-xs text-slate-400 font-mono">{p.actualizado}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="px-2 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md">Editar</button>
                      <button className={`px-2 py-1 text-xs rounded-md ${p.estado === 'activo' ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-green-600 bg-green-50 hover:bg-green-100'}`}>
                        {p.estado === 'activo' ? 'Desactivar' : 'Activar'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
