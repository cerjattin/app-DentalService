import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts'

const byPro = [
  { name: 'Dr. Pérez', pacientes: 12, procedimientos: 21, facturado: 4350 },
  { name: 'Dra. Gómez', pacientes: 9, procedimientos: 17, facturado: 3620 },
  { name: 'Dr. Ríos', pacientes: 6, procedimientos: 11, facturado: 1840 },
  { name: 'Dra. Martínez', pacientes: 2, procedimientos: 4, facturado: 510 },
]

const daily = [
  { dia: 'Lun', valor: 8200 }, { dia: 'Mar', valor: 9400 },
  { dia: 'Mié', valor: 7800 }, { dia: 'Jue', valor: 10200 },
  { dia: 'Vie', valor: 10320 },
]

const topProc = [
  { name: 'Limpieza dental', count: 42, color: '#1A6FE8' },
  { name: 'Consulta y examen', count: 38, color: '#16A34A' },
  { name: 'Obturación resina', count: 29, color: '#7C3AED' },
  { name: 'Extracción simple', count: 18, color: '#D97706' },
  { name: 'Tratamiento conducto', count: 11, color: '#0891B2' },
]

const COLORS = ['#1A6FE8', '#16A34A', '#7C3AED', '#D97706', '#0891B2']

export default function ProductionPage() {
  return (
    <div className="p-6 space-y-5">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Total facturado', value: 'ANG 46,100' },
          { label: 'Pacientes', value: '231' },
          { label: 'Facturas', value: '218' },
          { label: 'Procedimientos', value: '489' },
          { label: 'Promedio / paciente', value: 'ANG 199' },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-lg font-bold font-mono text-slate-800">{k.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <input type="date" defaultValue="2026-08-01" className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none" />
        <span className="text-xs text-slate-400">a</span>
        <input type="date" defaultValue="2026-08-12" className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none" />
        <select className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none">
          <option>Todos los profesionales</option>
          <option>Dr. Pérez</option>
          <option>Dra. Gómez</option>
        </select>
        <select className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none">
          <option>Todos los estados</option>
          <option>Cerrada</option>
          <option>Declarada</option>
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Daily bar chart */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Producción diaria — semana actual (ANG)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={daily} barSize={32}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="dia" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} width={50} />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0' }}
                formatter={(v) => [`ANG ${Number(v).toLocaleString()}`, 'Producción']}
              />
              <Bar dataKey="valor" fill="#1A6FE8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Top procedures pie */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h3 className="text-sm font-semibold text-slate-800 mb-4">Procedimientos más realizados</h3>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={topProc} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                {topProc.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {topProc.map((p, i) => (
              <div key={p.name} className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  <span className="text-[11px] text-slate-600 truncate">{p.name}</span>
                </div>
                <span className="text-[11px] font-mono font-semibold text-slate-700">{p.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* By professional table */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-3.5 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-slate-800">Producción por profesional</h3>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100">
              {['Profesional', 'Pacientes', 'Procedimientos', 'Facturado', 'Detalle'].map((h) => (
                <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-5 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {byPro.map((p, i) => (
              <tr key={p.name} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
                      style={{ backgroundColor: COLORS[i] }}
                    >
                      {p.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <span className="text-sm font-medium text-slate-700">{p.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-sm font-mono text-slate-700">{p.pacientes}</td>
                <td className="px-5 py-3 text-sm font-mono text-slate-700">{p.procedimientos}</td>
                <td className="px-5 py-3 text-sm font-mono font-semibold text-slate-800">ANG {p.facturado.toLocaleString()}</td>
                <td className="px-5 py-3">
                  <button className="text-xs text-blue-600 hover:underline">Ver detalle →</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
