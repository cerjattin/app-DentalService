import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const patients = [
  { id: 1, hora: '08:00', paciente: 'Carmen Willems', svb: '123456789', profesional: 'Dr. Pérez', motivo: 'Limpieza dental', estado: 'cerrada' as const, factura: 'SVB-00231' },
  { id: 2, hora: '08:30', paciente: 'Roberto Cijntje', svb: '234567890', profesional: 'Dra. Gómez', motivo: 'Extracción molar', estado: 'firmada' as const, factura: 'SVB-00232' },
  { id: 3, hora: '09:00', paciente: 'Marisela Hato', svb: '345678901', profesional: 'Dr. Pérez', motivo: 'Consulta general', estado: 'pendiente-firma' as const, factura: 'SVB-00233' },
  { id: 4, hora: '09:30', paciente: 'Louis Martina', svb: '456789012', profesional: 'Dr. Ríos', motivo: 'Obturación', estado: 'atencion' as const, factura: '—' },
  { id: 5, hora: '10:00', paciente: 'Jolanda Bikker', svb: '567890123', profesional: 'Dra. Gómez', motivo: 'Periodoncia', estado: 'espera' as const, factura: '—' },
  { id: 6, hora: '10:30', paciente: 'Egbert Seferina', svb: '678901234', profesional: 'Dr. Pérez', motivo: 'Revisión ortodoncia', estado: 'checkin' as const, factura: '—' },
  { id: 7, hora: '11:00', paciente: 'Nathalie Pieters', svb: '789012345', profesional: 'Dr. Ríos', motivo: 'Extracción', estado: 'programada' as const, factura: '—' },
]

interface ReceptionDashboardProps {
  onNavigate: (page: Page) => void
}

export default function ReceptionDashboard({ onNavigate }: ReceptionDashboardProps) {
  const [searchQ, setSearchQ] = useState('')
  const [filter, setFilter] = useState('todos')

  const filtered = patients.filter((p) => {
    const matchQ = !searchQ ||
      p.paciente.toLowerCase().includes(searchQ.toLowerCase()) ||
      p.svb.includes(searchQ) ||
      p.profesional.toLowerCase().includes(searchQ.toLowerCase())
    const matchF = filter === 'todos' || p.estado === filter
    return matchQ && matchF
  })

  const pendientesFirma = patients.filter((p) => p.estado === 'pendiente-firma').length
  const enAtencion = patients.filter((p) => p.estado === 'atencion').length
  const enEspera = patients.filter((p) => p.estado === 'espera').length

  const actionLabel = (estado: string) => {
    if (estado === 'checkin') return 'Check-in'
    if (estado === 'programada') return 'Registrar llegada'
    if (estado === 'espera') return 'Ver cita'
    if (estado === 'atencion') return 'Ver cita'
    if (estado === 'pendiente-firma') return 'Firmar'
    if (estado === 'firmada') return 'Cerrar'
    if (estado === 'cerrada') return 'Ver PDF'
    return 'Ver'
  }

  return (
    <div className="p-6 space-y-5">
      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'En espera', value: enEspera, color: '#D97706', bg: '#FEF3C7' },
          { label: 'En atención', value: enAtencion, color: '#4F46E5', bg: '#EEF2FF' },
          { label: 'Pendientes firma', value: pendientesFirma, color: '#DC2626', bg: '#FEE2E2' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-200 p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl font-bold" style={{ backgroundColor: s.bg, color: s.color }}>
              {s.value}
            </div>
            <span className="text-sm text-slate-600">{s.label}</span>
          </div>
        ))}
      </div>

      {/* Search + filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-64">
            <input
              type="text"
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Buscar por nombre, documento, SVB Card, teléfono..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-slate-50 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
          </div>
          <div className="flex items-center gap-1">
            {['todos', 'espera', 'atencion', 'pendiente-firma', 'cerrada'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
                  filter === f ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {f === 'todos' ? 'Todos' : f === 'atencion' ? 'En atención' : f === 'pendiente-firma' ? 'Pend. firma' : f === 'cerrada' ? 'Cerrada' : 'En espera'}
              </button>
            ))}
          </div>
          <button
            onClick={() => onNavigate('new-patient')}
            className="px-4 py-2 text-xs font-semibold text-white rounded-lg transition-all hover:opacity-90"
            style={{ backgroundColor: '#1A6FE8' }}
          >
            + Nuevo paciente
          </button>
        </div>
      </div>

      {/* Patients table */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-3.5 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-slate-800">Pacientes de hoy — {new Date().toLocaleDateString('es-CW', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Hora', 'Paciente', 'SVB Card', 'Profesional', 'Motivo', 'Estado', 'Factura', 'Acción'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-4 py-3 text-xs font-mono font-medium text-slate-600">{p.hora}</td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => onNavigate('patient-detail')}
                      className="text-sm font-medium text-blue-600 hover:underline text-left"
                    >
                      {p.paciente}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-600">{p.svb}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{p.profesional}</td>
                  <td className="px-4 py-3 text-xs text-slate-600">{p.motivo}</td>
                  <td className="px-4 py-3">
                    <Badge variant={p.estado} dot size="sm" />
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{p.factura}</td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => {
                        if (p.estado === 'pendiente-firma') onNavigate('signature')
                        else if (p.estado === 'cerrada') onNavigate('closed-invoice')
                        else onNavigate('appointment-detail')
                      }}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                        p.estado === 'pendiente-firma'
                          ? 'bg-orange-500 text-white hover:bg-orange-600'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {actionLabel(p.estado)}
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-sm text-slate-400">
                    No hay pacientes que coincidan con la búsqueda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
