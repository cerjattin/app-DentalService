import Badge from '../components/Badge'
import type { Page } from '../types'

const timelineSteps = [
  { label: 'Programada', done: true, current: false },
  { label: 'Check-in', done: true, current: false },
  { label: 'Atención', done: true, current: true },
  { label: 'Facturación', done: false, current: false },
  { label: 'Firma', done: false, current: false },
  { label: 'Cerrada', done: false, current: false },
]

interface AppointmentDetailPageProps {
  onNavigate: (page: Page) => void
}

export default function AppointmentDetailPage({ onNavigate }: AppointmentDetailPageProps) {
  return (
    <div className="p-6 max-w-3xl space-y-5">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-800">Cita #APT-000458</h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">Martes 12/08/2026 · 09:00 AM</p>
          </div>
          <Badge variant="atencion" />
        </div>
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Paciente', value: 'Marisela Hato' },
            { label: 'SVB Card', value: '345678901' },
            { label: 'Fecha de nacimiento', value: '22/11/1990' },
            { label: 'Cita #', value: 'APT-000458' },
            { label: 'Profesional', value: 'Dr. Juan Pérez' },
            { label: 'Motivo', value: 'Consulta general' },
          ].map((f) => (
            <div key={f.label}>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">{f.label}</div>
              <div className="text-sm font-semibold text-slate-800">{f.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Progreso de la cita</h3>
        <div className="flex items-center">
          {timelineSteps.map((step, i) => (
            <div key={step.label} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    step.done
                      ? 'bg-green-500 text-white'
                      : step.current
                      ? 'ring-2 ring-blue-500 bg-blue-50 text-blue-700'
                      : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  {step.done ? '✓' : i + 1}
                </div>
                <div
                  className={`text-[10px] mt-1 font-medium whitespace-nowrap ${
                    step.current ? 'text-blue-600' : step.done ? 'text-green-600' : 'text-slate-400'
                  }`}
                >
                  {step.label}
                </div>
              </div>
              {i < timelineSteps.length - 1 && (
                <div className={`flex-1 h-0.5 mx-1 ${step.done ? 'bg-green-400' : 'bg-slate-200'}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3 flex-wrap">
        <button
          onClick={() => onNavigate('clinical')}
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          Continuar atención
        </button>
        <button
          onClick={() => onNavigate('invoice-detail')}
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90"
          style={{ backgroundColor: '#D97706' }}
        >
          Ver factura
        </button>
        <button
          onClick={() => onNavigate('agenda')}
          className="px-5 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
        >
          Volver a agenda
        </button>
      </div>
    </div>
  )
}
