import { useRef, useState, useEffect } from 'react'
import type { Page } from '../types'

interface SignaturePageProps {
  onNavigate: (page: Page) => void
}

export default function SignaturePage({ onNavigate }: SignaturePageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [drawing, setDrawing] = useState(false)
  const [hasSignature, setHasSignature] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const lastPos = useRef<{ x: number; y: number } | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    ctx.strokeStyle = '#0B1F3A'
    ctx.lineWidth = 2.5
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
  }, [])

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    return { x: e.clientX - rect.left, y: e.clientY - rect.top }
  }

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    setDrawing(true)
    setHasSignature(true)
    lastPos.current = getPos(e)
  }

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!ctx || !lastPos.current) return
    const pos = getPos(e)
    ctx.beginPath()
    ctx.moveTo(lastPos.current.x, lastPos.current.y)
    ctx.lineTo(pos.x, pos.y)
    ctx.stroke()
    lastPos.current = pos
  }

  const onPointerUp = () => {
    setDrawing(false)
    lastPos.current = null
  }

  const clearSignature = () => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!ctx || !canvas) return
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    setHasSignature(false)
  }

  const handleConfirm = () => {
    if (!hasSignature) return
    setConfirmed(true)
    setTimeout(() => {
      onNavigate('closed-invoice')
    }, 1500)
  }

  return (
    <div className="p-6 max-w-3xl space-y-5">
      {/* Invoice summary */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">Resumen de factura</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'Paciente', value: 'Marisela Hato' },
            { label: 'SVB Card', value: '345678901' },
            { label: 'Fecha', value: '12/08/2026' },
            { label: 'Profesional', value: 'Dr. Juan Pérez' },
            { label: 'Procedimientos', value: '3' },
            { label: 'Total', value: 'ANG 395.00' },
          ].map((f) => (
            <div key={f.label}>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-0.5">{f.label}</div>
              <div className="text-sm font-semibold text-slate-800">{f.value}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 px-4 py-3 bg-slate-50 rounded-lg border border-slate-200">
          <p className="text-sm text-slate-600 italic">
            "He revisado los procedimientos registrados correspondientes a mi atención."
          </p>
        </div>
      </div>

      {/* Signature pad */}
      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-slate-800">Firmar aquí</h3>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Compatible con tableta digitalizadora, táctil o mouse</span>
          </div>
        </div>
        <div
          className="border-2 border-dashed border-slate-300 rounded-xl overflow-hidden"
          style={{ backgroundColor: '#FAFBFC' }}
        >
          <canvas
            ref={canvasRef}
            width={720}
            height={200}
            className="signature-canvas w-full"
            style={{ height: '200px', touchAction: 'none' }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
          />
          {!hasSignature && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center" style={{ height: '200px', marginTop: '-200px' }}>
              <span className="text-slate-300 text-sm">Dibuje su firma aquí</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={clearSignature}
            className="px-3 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Limpiar firma
          </button>
          <button
            onClick={clearSignature}
            className="px-3 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Reintentar
          </button>
        </div>
      </div>

      {/* Actions */}
      {confirmed ? (
        <div className="flex items-center gap-2 px-4 py-3 bg-green-50 border border-green-200 rounded-lg">
          <span className="text-green-600">✓</span>
          <span className="text-sm text-green-700 font-medium">Firma registrada. Cerrando factura...</span>
        </div>
      ) : (
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('invoice-detail')}
            className="px-5 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
          >
            Volver
          </button>
          <button
            onClick={() => { if (hasSignature) setShowConfirm(true) }}
            disabled={!hasSignature}
            className="px-6 py-2.5 text-sm font-semibold text-white rounded-lg transition-all hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ backgroundColor: '#16A34A' }}
          >
            Firmar y cerrar factura
          </button>
        </div>
      )}

      {/* Confirmation modal */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl p-6 w-full max-w-sm mx-4">
            <h3 className="text-base font-semibold text-slate-800 mb-2">Confirmar cierre de factura</h3>
            <p className="text-sm text-slate-600 mb-5 leading-relaxed">
              "Una vez cerrada la factura no podrá modificarse de manera normal."
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 py-2.5 text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => { setShowConfirm(false); handleConfirm() }}
                className="flex-1 py-2.5 text-sm font-semibold text-white rounded-lg transition-all hover:opacity-90"
                style={{ backgroundColor: '#16A34A' }}
              >
                Confirmar cierre
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
