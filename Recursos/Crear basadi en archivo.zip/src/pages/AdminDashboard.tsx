import { useState } from 'react'
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'
import Badge from '../components/Badge'
import type { Page } from '../types'

const hourlyData = [
  { hour: '08:00', valor: 320 }, { hour: '09:00', valor: 870 },
  { hour: '10:00', valor: 1450 }, { hour: '11:00', valor: 2100 },
  { hour: '12:00', valor: 2650 }, { hour: '13:00', valor: 2800 },
  { hour: '14:00', valor: 3400 }, { hour: '15:00', valor: 4100 },
  { hour: '16:00', valor: 4350 }, { hour: '17:00', valor: 4580 },
]

const professionals = [
  { name: 'Dr. Juan Pérez', patients: 12, procedures: 21, production: 4350, pct: 42 },
  { name: 'Dra. María Gómez', patients: 9, procedures: 17, production: 3620, pct: 35 },
  { name: 'Dr. Carlos Ríos', patients: 6, procedures: 11, production: 1840, pct: 18 },
  { name: 'Dra. Ana Martínez', patients: 2, procedures: 4, production: 510, pct: 5 },
]

const kpis = [
  { label: 'Producción de hoy', value: 'ANG 10,320', icon: '💰', delta: '+12%', color: '#1A6FE8' },
  { label: 'Facturado SVB', value: 'ANG 9,850', icon: '📋', delta: '+8%', color: '#16A34A' },
  { label: 'Pacientes atendidos', value: '29', icon: '👤', delta: '+3', color: '#7C3AED' },
  { label: 'Citas de hoy', value: '34', icon: '📅', delta: '5 pendientes', color: '#0891B2' },
  { label: 'Pendientes de firma', value: '4', icon: '✍️', delta: 'urgente', color: '#D97706' },
  { label: 'Facturas cerradas', value: '25', icon: '✅', delta: 'hoy', color: '#16A34A' },
  { label: 'Por declarar', value: '148', icon: '📤', delta: 'este mes', color: '#6366F1' },
]

interface AdminDashboardProps {
  onNavigate: (page: Page) => void
}

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [period, setPeriod] = useState('hoy')

  return (
    <div className="p-6 space-y-6">
      {/* Period filters */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-1">
          {['hoy', 'ayer', 'semana', 'mes', 'personalizado'].map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${
                period === p ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
        <select className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
          <option>Todos los profesionales</option>
          <option>Dr. Juan Pérez</option>
          <option>Dra. María Gómez</option>
        </select>
      </div>

      {/* KPI grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-start justify-between mb-2">
              <span className="text-lg">{k.icon}</span>
              <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-green-50 text-green-600">{k.delta}</span>
            </div>
            <div className="text-lg font-bold text-slate-800 leading-tight font-mono">{k.value}</div>
            <div className="text-[11px] text-slate-500 mt-0.5 leading-tight">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Area chart */}
        <div className="lg:col-span-3 bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Producción acumulada del día</h3>
              <p className="text-xs text-slate-400">Valor facturado por hora — ANG</p>
            </div>
            <div className="text-xs font-mono font-semibold text-green-600">ANG 4,580</div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={hourlyData}>
              <defs>
                <linearGradient id="colorValor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1A6FE8" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#1A6FE8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} width={45} />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
                formatter={(v) => [`ANG ${Number(v).toLocaleString()}`, 'Producción']}
              />
              <Area type="monotone" dataKey="valor" stroke="#1A6FE8" strokeWidth={2} fill="url(#colorValor)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Producción live */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Producción Live</h3>
              <p className="text-[10px] text-slate-400">Última actualización: 10:42 AM</p>
            </div>
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          </div>
          <div className="space-y-3">
            {professionals.map((p) => (
              <div key={p.name} className="group">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-700 truncate">{p.name}</span>
                  <span className="text-xs font-mono font-semibold text-slate-800">ANG {p.production.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${p.pct}%`, backgroundColor: '#1A6FE8' }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400">{p.pct}%</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">{p.patients} pac · {p.procedures} proc</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Producción por profesional table */}
      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-800">Producción por profesional</h3>
          <button
            onClick={() => onNavigate('production')}
            className="text-xs text-blue-600 hover:underline"
          >
            Ver detalle →
          </button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-100">
              {['Profesional', 'Pacientes', 'Procedimientos', 'Producción', '% Total'].map((h) => (
                <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-5 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {professionals.map((p, i) => (
              <tr key={p.name} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold text-white"
                      style={{ backgroundColor: ['#1A6FE8', '#16A34A', '#7C3AED', '#0891B2'][i] }}
                    >
                      {p.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <span className="text-sm font-medium text-slate-700">{p.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-sm font-mono text-slate-700">{p.patients}</td>
                <td className="px-5 py-3 text-sm font-mono text-slate-700">{p.procedures}</td>
                <td className="px-5 py-3 text-sm font-mono font-semibold text-slate-800">ANG {p.production.toLocaleString()}</td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: `${p.pct}%` }} />
                    </div>
                    <span className="text-xs text-slate-500">{p.pct}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
