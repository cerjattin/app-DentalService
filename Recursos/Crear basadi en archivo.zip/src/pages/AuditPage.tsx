import { useState } from 'react'

const logs = [
  { id: 1, usuario: 'dra.gomez', fecha: '12/08/2026', hora: '10:47 AM', accion: 'Factura cerrada', paciente: 'Roberto Cijntje', cita: 'APT-000457', factura: 'SVB-00232', datos: 'Estado: Firmada → Cerrada', motivo: '—' },
  { id: 2, usuario: 'recepcion', fecha: '12/08/2026', hora: '10:45 AM', accion: 'Firma capturada', paciente: 'Roberto Cijntje', cita: 'APT-000457', factura: 'SVB-00232', datos: 'Firma digital registrada', motivo: '—' },
  { id: 3, usuario: 'dr.perez', fecha: '12/08/2026', hora: '10:12 AM', accion: 'Procedimiento agregado', paciente: 'Marisela Hato', cita: 'APT-000458', factura: 'SVB-00233', datos: 'T003 — Limpieza dental · ANG 120', motivo: '—' },
  { id: 4, usuario: 'recepcion', fecha: '12/08/2026', hora: '09:30 AM', accion: 'Check-in realizado', paciente: 'Marisela Hato', cita: 'APT-000458', factura: '—', datos: 'Estado: Programada → Check-in', motivo: '—' },
  { id: 5, usuario: 'admin', fecha: '12/08/2026', hora: '08:55 AM', accion: 'Factura corregida', paciente: 'Carmen Willems', cita: 'APT-000451', factura: 'SVB-00228', datos: 'Procedimiento T009 modificado: ANG 600 → ANG 650', motivo: 'Error en tarifa registrada' },
  { id: 6, usuario: 'recepcion', fecha: '12/08/2026', hora: '08:30 AM', accion: 'Paciente creado', paciente: 'Jolanda Bikker', cita: '—', factura: '—', datos: 'SVB: 567890123', motivo: '—' },
  { id: 7, usuario: 'admin', fecha: '11/08/2026', hora: '05:30 PM', accion: 'Declaración exportada', paciente: '—', cita: '—', factura: 'DEC-2026-07', datos: '162 registros exportados (CSV)', motivo: '—' },
]

const actionColors: Record<string, string> = {
  'Factura cerrada': 'text-green-700 bg-green-100',
  'Firma capturada': 'text-emerald-700 bg-emerald-100',
  'Procedimiento agregado': 'text-blue-700 bg-blue-100',
  'Check-in realizado': 'text-sky-700 bg-sky-100',
  'Factura corregida': 'text-amber-700 bg-amber-100',
  'Paciente creado': 'text-purple-700 bg-purple-100',
  'Declaración exportada': 'text-indigo-700 bg-indigo-100',
}

export default function AuditPage() {
  const [search, setSearch] = useState('')

  const filtered = logs.filter(
    (l) =>
      !search ||
      l.usuario.includes(search.toLowerCase()) ||
      l.accion.toLowerCase().includes(search.toLowerCase()) ||
      l.paciente.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por usuario, acción, paciente..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
        </div>
        <input type="date" defaultValue="2026-08-12" className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white focus:outline-none" />
        <select className="text-xs border border-slate-200 rounded-lg px-3 py-2 bg-white text-slate-600 focus:outline-none">
          <option>Todos los usuarios</option>
          <option>admin</option>
          <option>recepcion</option>
          <option>dr.perez</option>
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200">
        <div className="px-5 py-3.5 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-slate-800">Audit Log — {filtered.length} registros</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100">
                {['Usuario', 'Fecha', 'Hora', 'Acción', 'Paciente', 'Cita', 'Factura', 'Datos modificados', 'Motivo'].map((h) => (
                  <th key={h} className="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide px-4 py-3 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map((l) => (
                <tr key={l.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-3 text-xs font-mono font-semibold text-slate-700">{l.usuario}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{l.fecha}</td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{l.hora}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${actionColors[l.accion] ?? 'text-slate-600 bg-slate-100'}`}>
                      {l.accion}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600">{l.paciente}</td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{l.cita}</td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-500">{l.factura}</td>
                  <td className="px-4 py-3 text-xs text-slate-600 max-w-48">{l.datos}</td>
                  <td className="px-4 py-3 text-xs text-slate-400">{l.motivo}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
