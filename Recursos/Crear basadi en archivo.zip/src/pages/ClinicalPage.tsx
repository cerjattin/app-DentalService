import { useState } from 'react'
import Badge from '../components/Badge'
import type { Page } from '../types'

const proceduresCatalog = [
  { code: 'T001', name: 'Consulta y examen dental', tarifa: 85.00 },
  { code: 'T002', name: 'Radiografía periapical', tarifa: 45.00 },
  { code: 'T003', name: 'Limpieza dental (profilaxis)', tarifa: 120.00 },
  { code: 'T004', name: 'Obturación (amalgama 1 superficie)', tarifa: 95.00 },
  { code: 'T005', name: 'Obturación (resina 1 superficie)', tarifa: 110.00 },
  { code: 'T006', name: 'Extracción simple', tarifa: 130.00 },
  { code: 'T007', name: 'Extracción quirúrgica', tarifa: 220.00 },
  { code: 'T008', name: 'Tratamiento de conducto (unirradicular)', tarifa: 380.00 },
  { code: 'T009', name: 'Corona metal-cerámica', tarifa: 650.00 },
  { code: 'T010', name: 'Detartraje supragingival', tarifa: 100.00 },
]

const icd10 = [
  { code: 'K02.1', desc: 'Caries dentinaria' },
  { code: 'K04.0', desc: 'Pulpitis' },
  { code: 'K05.1', desc: 'Gingivitis crónica' },
  { code: 'K08.1', desc: 'Pérdida de dientes por accidente' },
  { code: 'K08.3', desc: 'Raíz dental retenida' },
  { code: 'Z01.2', desc: 'Examen dental de rutina' },
]

interface Procedure {
  id: number
  code: string
  name: string
  tarifa: number
  cantidad: number
  autorizacion: string
  asistencia: 'Y' | 'N'
  poli: 'P' | 'K'
  nota: string
}

interface ClinicalPageProps {
  onNavigate: (page: Page) => void
}

export default function ClinicalPage({ onNavigate }: ClinicalPageProps) {
  const [tab, setTab] = useState<'atencion' | 'facturacion' | 'historial'>('atencion')
  const [diagSearch, setDiagSearch] = useState('')
  const [selectedDiag, setSelectedDiag] = useState<{ code: string; desc: string } | null>(null)
  const [procSearch, setProcSearch] = useState('')
  const [showProcSearch, setShowProcSearch] = useState(false)
  const [procedures, setProcedures] = useState<Procedure[]>([])
  const [observations, setObservations] = useState('')
  const [finalized, setFinalized] = useState(false)

  const filteredICD = icd10.filter(
    (d) =>
      d.code.toLowerCase().includes(diagSearch.toLowerCase()) ||
      d.desc.toLowerCase().includes(diagSearch.toLowerCase())
  )

  const filteredProcs = proceduresCatalog.filter(
    (p) =>
      p.code.toLowerCase().includes(procSearch.toLowerCase()) ||
      p.name.toLowerCase().includes(procSearch.toLowerCase())
  )

  const addProcedure = (p: (typeof proceduresCatalog)[0]) => {
    setProcedures((prev) => [
      ...prev,
      { id: Date.now(), code: p.code, name: p.name, tarifa: p.tarifa, cantidad: 1, autorizacion: '', asistencia: 'N', poli: 'P', nota: '' },
    ])
    setShowProcSearch(false)
    setProcSearch('')
  }

  const updateProc = (id: number, field: string, value: string | number) => {
    setProcedures((prev) => prev.map((p) => (p.id === id ? { ...p, [field]: value } : p)))
  }

  const removeProc = (id: number) => setProcedures((prev) => prev.filter((p) => p.id !== id))

  const total = procedures.reduce((s, p) => s + p.tarifa * p.cantidad, 0)

  const handleFinalize = () => {
    if (!selectedDiag) return alert('⚠ Falta código de diagnóstico.')
    if (procedures.length === 0) return alert('⚠ Debe registrar al menos un procedimiento.')
    setFinalized(true)
    setTimeout(() => {
      onNavigate('invoice-detail')
    }, 1200)
  }

  return (
    <div className="p-6 flex gap-5">
      {/* Main content */}
      <div className="flex-1 min-w-0 space-y-4">
        {/* Patient card */}
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white"
                style={{ backgroundColor: '#1A6FE8' }}
              >
                MH
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-800">Marisela Hato</div>
                <div className="text-xs text-slate-500 font-mono">SVB 345678901 · Nac. 22/11/1990</div>
              </div>
            </div>
            <div className="flex items-center gap-3 text-right">
              <div>
                <div className="text-xs text-slate-400">Cita</div>
                <div className="text-xs font-mono font-semibold text-slate-700">APT-000458</div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Profesional</div>
                <div className="text-xs font-semibold text-slate-700">Dr. Juan Pérez</div>
              </div>
              <Badge variant="atencion" size="sm" />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="border-b border-slate-200 flex">
            {(['atencion', 'facturacion', 'historial'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-5 py-3 text-sm font-medium capitalize transition-colors border-b-2 -mb-px ${
                  tab === t
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {t === 'atencion' ? 'Atención' : t === 'facturacion' ? 'Facturación' : 'Historial'}
              </button>
            ))}
          </div>

          <div className="p-5">
            {tab === 'atencion' && (
              <div className="space-y-5">
                {/* Diagnosis */}
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-3">Diagnóstico</h4>
                  {selectedDiag ? (
                    <div className="flex items-center gap-3 px-3 py-2.5 bg-blue-50 border border-blue-200 rounded-lg">
                      <span className="text-xs font-mono font-bold text-blue-700">{selectedDiag.code}</span>
                      <span className="text-sm text-blue-800 flex-1">{selectedDiag.desc}</span>
                      <button onClick={() => setSelectedDiag(null)} className="text-blue-400 hover:text-blue-600 text-xs">✕ cambiar</button>
                    </div>
                  ) : (
                    <div>
                      <div className="relative">
                        <input
                          type="text"
                          value={diagSearch}
                          onChange={(e) => setDiagSearch(e.target.value)}
                          placeholder="Buscar por código ICD-10 o descripción..."
                          className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
                        />
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
                      </div>
                      {diagSearch && (
                        <div className="mt-1 border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                          {filteredICD.map((d) => (
                            <button
                              key={d.code}
                              onClick={() => { setSelectedDiag(d); setDiagSearch('') }}
                              className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-blue-50 transition-colors text-left border-b border-slate-100 last:border-b-0"
                            >
                              <span className="text-xs font-mono font-bold text-blue-600 w-16">{d.code}</span>
                              <span className="text-sm text-slate-700">{d.desc}</span>
                            </button>
                          ))}
                          {filteredICD.length === 0 && (
                            <div className="px-3 py-3 text-sm text-slate-400">Sin resultados.</div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Observations */}
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-3">Observaciones clínicas</h4>
                  <textarea
                    value={observations}
                    onChange={(e) => setObservations(e.target.value)}
                    placeholder="Registre observaciones del examen clínico..."
                    rows={3}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 resize-none"
                  />
                </div>
              </div>
            )}

            {tab === 'facturacion' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Procedimientos realizados</h4>
                  <button
                    onClick={() => setShowProcSearch(true)}
                    className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg"
                    style={{ backgroundColor: '#1A6FE8' }}
                  >
                    + Agregar procedimiento
                  </button>
                </div>

                {/* Procedure search */}
                {showProcSearch && (
                  <div className="border border-blue-200 rounded-xl bg-blue-50/40 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="relative flex-1">
                        <input
                          type="text"
                          value={procSearch}
                          onChange={(e) => setProcSearch(e.target.value)}
                          placeholder="Buscar por código SVB, nombre o descripción..."
                          autoFocus
                          className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                        />
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm">🔍</span>
                      </div>
                      <button onClick={() => setShowProcSearch(false)} className="text-slate-400 hover:text-slate-600 text-sm px-2">✕</button>
                    </div>
                    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-slate-100 bg-slate-50">
                            <th className="text-left text-[11px] font-semibold text-slate-500 uppercase px-3 py-2">Código</th>
                            <th className="text-left text-[11px] font-semibold text-slate-500 uppercase px-3 py-2">Procedimiento</th>
                            <th className="text-left text-[11px] font-semibold text-slate-500 uppercase px-3 py-2">Tarifa</th>
                            <th className="px-3 py-2" />
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {(procSearch ? filteredProcs : proceduresCatalog.slice(0, 6)).map((p) => (
                            <tr key={p.code} className="hover:bg-blue-50/50 transition-colors">
                              <td className="px-3 py-2 text-xs font-mono font-bold text-slate-700">{p.code}</td>
                              <td className="px-3 py-2 text-xs text-slate-700">{p.name}</td>
                              <td className="px-3 py-2 text-xs font-mono text-slate-600">ANG {p.tarifa.toFixed(2)}</td>
                              <td className="px-3 py-2">
                                <button
                                  onClick={() => addProcedure(p)}
                                  className="px-2.5 py-1 text-xs font-semibold text-white rounded-md"
                                  style={{ backgroundColor: '#1A6FE8' }}
                                >
                                  Agregar
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Procedures list */}
                {procedures.length > 0 ? (
                  <div className="space-y-3">
                    {procedures.map((p) => (
                      <div key={p.id} className="border border-slate-200 rounded-xl p-4 bg-slate-50/30">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <span className="text-xs font-mono font-bold text-blue-700">{p.code}</span>
                            <span className="text-sm font-medium text-slate-800 ml-2">{p.name}</span>
                          </div>
                          <button onClick={() => removeProc(p.id)} className="text-red-400 hover:text-red-600 text-xs transition-colors">✕ eliminar</button>
                        </div>
                        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                          <div>
                            <label className="block text-[10px] text-slate-500 mb-1">Cantidad</label>
                            <input
                              type="number"
                              min={1}
                              value={p.cantidad}
                              onChange={(e) => updateProc(p.id, 'cantidad', parseInt(e.target.value) || 1)}
                              className="w-full px-2 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-500 mb-1">Autorización ID</label>
                            <input
                              type="text"
                              value={p.autorizacion}
                              onChange={(e) => updateProc(p.id, 'autorizacion', e.target.value)}
                              placeholder="Núm. autorización"
                              className="w-full px-2 py-1.5 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-500 mb-1">Asistencia</label>
                            <select
                              value={p.asistencia}
                              onChange={(e) => updateProc(p.id, 'asistencia', e.target.value)}
                              className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none"
                            >
                              <option value="Y">Y — Sí</option>
                              <option value="N">N — No</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-500 mb-1">Poli/Clínica</label>
                            <select
                              value={p.poli}
                              onChange={(e) => updateProc(p.id, 'poli', e.target.value)}
                              className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none"
                            >
                              <option value="P">P — Policlínica</option>
                              <option value="K">K — Clínica</option>
                            </select>
                          </div>
                          <div className="col-span-2">
                            <label className="block text-[10px] text-slate-500 mb-1">Nota adicional (máx. 100 car.)</label>
                            <input
                              type="text"
                              value={p.nota}
                              onChange={(e) => updateProc(p.id, 'nota', e.target.value.slice(0, 100))}
                              placeholder="Observación..."
                              className="w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                            />
                          </div>
                        </div>
                        <div className="flex justify-end mt-2">
                          <span className="text-xs font-mono font-semibold text-slate-700">
                            ANG {(p.tarifa * p.cantidad).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-10 text-center text-sm text-slate-400 border border-dashed border-slate-200 rounded-xl">
                    No hay procedimientos registrados. Haga clic en "Agregar procedimiento" para comenzar.
                  </div>
                )}
              </div>
            )}

            {tab === 'historial' && (
              <div className="py-10 text-center text-sm text-slate-400">
                Historial de atenciones anteriores del paciente.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Resumen sticky sidebar */}
      <div className="w-64 flex-shrink-0">
        <div className="sticky top-4 bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100" style={{ backgroundColor: '#0B1F3A' }}>
            <h3 className="text-sm font-semibold text-white">Resumen</h3>
          </div>
          <div className="p-4 space-y-3">
            <div>
              <div className="text-xs text-slate-500 mb-0.5">Paciente</div>
              <div className="text-sm font-semibold text-slate-800">Marisela Hato</div>
            </div>
            <div className="pt-2 border-t border-slate-100">
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span>Procedimientos</span>
                <span className="font-mono font-medium text-slate-700">{procedures.length}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span>Diagnóstico</span>
                <span className={`font-mono text-${selectedDiag ? 'slate-700' : 'red-400'}`}>
                  {selectedDiag ? selectedDiag.code : 'Falta'}
                </span>
              </div>
            </div>
            <div className="pt-2 border-t border-slate-100">
              <div className="flex justify-between text-xs text-slate-500 mb-1">
                <span>Subtotal</span>
                <span className="font-mono text-slate-700">ANG {total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold">
                <span className="text-slate-800">Total</span>
                <span className="font-mono" style={{ color: '#1A6FE8' }}>ANG {total.toFixed(2)}</span>
              </div>
            </div>
            <div className="pt-1">
              <div className="text-xs text-slate-500 mb-1">Estado</div>
              <Badge variant="atencion" size="sm" />
            </div>
          </div>

          {finalized ? (
            <div className="mx-4 mb-4 px-3 py-2.5 bg-green-50 border border-green-200 rounded-lg text-center">
              <p className="text-xs text-green-700 font-semibold">✓ Atención finalizada</p>
              <p className="text-[11px] text-green-600 mt-0.5">Generando factura...</p>
            </div>
          ) : (
            <div className="px-4 pb-4 space-y-2">
              <button
                onClick={handleFinalize}
                className="w-full py-2.5 text-sm font-semibold text-white rounded-lg transition-all hover:opacity-90"
                style={{ backgroundColor: '#16A34A' }}
              >
                Finalizar atención
              </button>
              <button
                onClick={() => setTab('facturacion')}
                className="w-full py-2 text-xs text-slate-500 hover:text-slate-700 transition-colors"
              >
                Ver procedimientos
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
