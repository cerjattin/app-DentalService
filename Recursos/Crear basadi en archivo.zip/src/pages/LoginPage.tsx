import { useState } from 'react'
import type { Role } from '../types'

interface LoginPageProps {
  onLogin: (role: Role) => void
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [connected] = useState(true)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!username || !password) {
      setError('Por favor complete todos los campos.')
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      if (username === 'admin') onLogin('admin')
      else if (username === 'recepcion') onLogin('reception')
      else if (username === 'doctor') onLogin('professional')
      else setError('Credenciales incorrectas. Intente de nuevo.')
    }, 900)
  }

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#F4F6F9' }}>
      {/* Left panel */}
      <div
        className="hidden lg:flex flex-col justify-between w-[400px] p-10"
        style={{ backgroundColor: '#0B1F3A' }}
      >
        <div>
          <div className="flex items-center gap-3 mb-12">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold"
              style={{ backgroundColor: '#1A6FE8' }}
            >
              OS
            </div>
            <div>
              <div className="text-white font-semibold">OdonthoServices</div>
              <div className="text-white/40 text-xs font-mono tracking-wider">SVB BILLING SYSTEM</div>
            </div>
          </div>
          <h2 className="text-white text-2xl font-semibold leading-snug mb-4">
            Sistema de facturación<br />SVB — Curaçao
          </h2>
          <p className="text-white/50 text-sm leading-relaxed">
            Plataforma interna para la gestión de pacientes, citas, procedimientos y declaraciones SVB de OdonthoServices.
          </p>
        </div>

        <div className="space-y-3">
          {[
            { icon: '🦷', label: 'Flujo de atención completo' },
            { icon: '📋', label: 'Facturación SVB integrada' },
            { icon: '✍️', label: 'Firma digital del paciente' },
            { icon: '📊', label: 'Declaraciones electrónicas' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-3">
              <span className="text-base">{item.icon}</span>
              <span className="text-white/60 text-sm">{item.label}</span>
            </div>
          ))}
        </div>

        <div className="text-white/20 text-xs font-mono">v2.4.1 · Red local OdonthoServices</div>
      </div>

      {/* Right: form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
            <div className="mb-6">
              <h1 className="text-xl font-semibold text-slate-800">Iniciar sesión</h1>
              <p className="text-sm text-slate-500 mt-1">Ingrese sus credenciales para continuar.</p>
            </div>

            {/* Server status */}
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs mb-5 ${connected ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
              <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
              {connected ? 'Servidor conectado — Red local OdonthoServices' : 'Sin conexión al servidor'}
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Usuario o correo</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin / recepcion / doctor"
                  className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Contraseña</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2.5 pr-10 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors text-sm"
                  >
                    {showPass ? '🙈' : '👁'}
                  </button>
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 px-3 py-2.5 bg-red-50 border border-red-100 rounded-lg">
                  <span className="text-red-500 text-sm">✕</span>
                  <span className="text-red-600 text-xs">{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-sm font-semibold text-white rounded-lg transition-all disabled:opacity-60"
                style={{ backgroundColor: '#1A6FE8' }}
              >
                {loading ? 'Verificando...' : 'Iniciar sesión'}
              </button>
            </form>

            <p className="text-[10px] text-slate-400 text-center mt-5">
              Demo: usuario <span className="font-mono text-slate-500">admin</span>, <span className="font-mono text-slate-500">recepcion</span> o <span className="font-mono text-slate-500">doctor</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
