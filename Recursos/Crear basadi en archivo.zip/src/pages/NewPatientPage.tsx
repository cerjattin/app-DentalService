import { useState } from 'react'
import type { Page } from '../types'

interface NewPatientPageProps {
  onNavigate: (page: Page) => void
}

export default function NewPatientPage({ onNavigate }: NewPatientPageProps) {
  const [saved, setSaved] = useState(false)
  const [form, setForm] = useState({
    nombre: '', apellidos: '', dob: '', sexo: '', documento: '',
    telefono: '', email: '', direccion: '',
    svbCard: '', svbEstado: '', svbVencimiento: '',
    medicoRemitente: '', codigoMedico: '', observaciones: '',
  })

  const update = (field: string, val: string) => setForm((f) => ({ ...f, [field]: val }))

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => {
      setSaved(false)
      onNavigate('patients')
    }, 1500)
  }

  return (
    <div className="p-6 max-w-4xl space-y-5">
      {saved && (
        <div className="flex items-center gap-2 px-4 py-3 bg-green-50 border border-green-200 rounded-lg">
          <span className="text-green-600">✓</span>
          <span className="text-sm text-green-700 font-medium">Paciente registrado correctamente.</span>
        </div>
      )}

      {/* Personal */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">
          Información personal
        </h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Nombre', field: 'nombre', placeholder: 'Ingrese nombre' },
            { label: 'Apellidos', field: 'apellidos', placeholder: 'Ingrese apellidos' },
          ].map(({ label, field, placeholder }) => (
            <div key={field}>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">{label}</label>
              <input
                type="text"
                value={form[field as keyof typeof form]}
                onChange={(e) => update(field, e.target.value)}
                placeholder={placeholder}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all"
              />
            </div>
          ))}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Fecha de nacimiento</label>
            <input
              type="date"
              value={form.dob}
              onChange={(e) => update('dob', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Sexo</label>
            <select
              value={form.sexo}
              onChange={(e) => update('sexo', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            >
              <option value="">Seleccionar...</option>
              <option value="M">Masculino</option>
              <option value="F">Femenino</option>
              <option value="O">Otro</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Documento de identidad</label>
            <input
              type="text"
              value={form.documento}
              onChange={(e) => update('documento', e.target.value)}
              placeholder="Número de documento"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Teléfono</label>
            <input
              type="tel"
              value={form.telefono}
              onChange={(e) => update('telefono', e.target.value)}
              placeholder="+599 9 000-0000"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Correo electrónico</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => update('email', e.target.value)}
              placeholder="correo@ejemplo.com"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Dirección</label>
            <input
              type="text"
              value={form.direccion}
              onChange={(e) => update('direccion', e.target.value)}
              placeholder="Ingrese dirección completa"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
        </div>
      </div>

      {/* SVB */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">
          Información SVB
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">SVB Seguro Card Number / VerzekerdeId</label>
            <input
              type="text"
              value={form.svbCard}
              onChange={(e) => update('svbCard', e.target.value)}
              placeholder="000000000 (9 dígitos)"
              maxLength={9}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
            {form.svbCard && form.svbCard.length !== 9 && (
              <p className="text-[11px] text-red-500 mt-1">✕ El SVB ID debe contener exactamente 9 dígitos.</p>
            )}
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Estado de afiliación</label>
            <select
              value={form.svbEstado}
              onChange={(e) => update('svbEstado', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            >
              <option value="">Seleccionar...</option>
              <option value="activo">Activo</option>
              <option value="vencido">Vencido</option>
              <option value="suspendido">Suspendido</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Fecha de vencimiento (si aplica)</label>
            <input
              type="date"
              value={form.svbVencimiento}
              onChange={(e) => update('svbVencimiento', e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
        </div>
      </div>

      {/* Additional */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm font-semibold text-slate-800 mb-4 pb-3 border-b border-slate-100">
          Información adicional
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Médico remitente</label>
            <input
              type="text"
              value={form.medicoRemitente}
              onChange={(e) => update('medicoRemitente', e.target.value)}
              placeholder="Nombre del médico"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Código del médico remitente</label>
            <input
              type="text"
              value={form.codigoMedico}
              onChange={(e) => update('codigoMedico', e.target.value)}
              placeholder="Código SVB"
              className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
            />
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Observaciones</label>
            <textarea
              value={form.observaciones}
              onChange={(e) => update('observaciones', e.target.value)}
              placeholder="Notas adicionales sobre el paciente..."
              rows={3}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 resize-none"
            />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3 pb-4">
        <button
          onClick={() => onNavigate('patients')}
          className="px-5 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
        >
          Cancelar
        </button>
        <button
          onClick={handleSave}
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity"
          style={{ backgroundColor: '#1A6FE8' }}
        >
          Guardar paciente
        </button>
        <button
          onClick={() => { handleSave(); }}
          className="px-5 py-2.5 text-sm font-semibold text-white rounded-lg hover:opacity-90 transition-opacity"
          style={{ backgroundColor: '#16A34A' }}
        >
          Guardar y crear cita
        </button>
      </div>
    </div>
  )
}
